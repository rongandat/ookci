<?php /* Smarty version Smarty-3.1.14, created on 2013-08-12 06:48:46
         compiled from "application\views\templates\common\bottom.html" */ ?>
<?php /*%%SmartyHeaderCode:1838252086885194095-54406727%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'c389aa8142aec8aac5bd138466d81d1a587913c4' => 
    array (
      0 => 'application\\views\\templates\\common\\bottom.html',
      1 => 1376282924,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1838252086885194095-54406727',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.14',
  'unifunc' => 'content_520868851b1b04_12554587',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_520868851b1b04_12554587')) {function content_520868851b1b04_12554587($_smarty_tpl) {?><?php if (!isset($_smarty_tpl->tpl_vars['class'])) $_smarty_tpl->tpl_vars['class'] = new Smarty_Variable(null);if ($_smarty_tpl->tpl_vars['class']->value = 'home'){?>
<div class="clear"></div>
<div class="accept">
    <h1>We Accept</h1>
    <div class="content">
        <img src="<?php echo base_url('public_html/images/visa.png');?>
"/>
    </div>
</div>
<div class="clear"></div>
<?php }?><?php }} ?>