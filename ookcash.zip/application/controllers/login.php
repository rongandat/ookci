<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Login extends MY_Controller {

    public function __construct() {
        parent::__construct();
        $this->lang->load('english', 'english');
    }

    public function index() {
        $error_log_login = $this->session->userdata('error_log_login');
        if (!$error_log_login)
            $error_log_login = 0;

        $login_id = $this->session->userdata('error_log_login');
        if ($login_id) {
            redirect(site_url('login/comfirm'));
        }
        $posts = $this->input->post();
        if ($posts) {

            $account_number = $posts['account_number'];
            $login_password = $posts['password'];
            $security_code = !empty($posts['security_code']) ? $posts['security_code'] : false;

            if (!empty($error_log_login) && $error_log_login > 3) {
                $secure_image_hash_string = $this->session->userdata('secure_image_hash_string');
                if ($security_code != $secure_image_hash_string)
                    $this->validator->addError('Turing Number', ERROR_SECURE_CODE_WRONG);
            }

            $this->validator->validateGeneral('Account Number', $account_number, _ERROR_FIELD_EMPTY);
            $this->validator->validateGeneral('Password', $login_password, _ERROR_FIELD_EMPTY);

            if (count($this->validator->errors) == 0) {
                $user = $this->user->checkLogin($account_number, $login_password);

                if (!$user) {
                    $this->validator->addError('Account Number/Password', ERROR_INVALID_ACCOUNT);
                    $error_log_login++;
                    $this->session->set_userdata('error_log_login', $error_log_login);
                    $this->data['validerrors'] = $this->validator->errors;
                } else {
                    $this->session->set_userdata('login_id', $user->user_id);

                    $current_ip = get_client_ip();
                    if (($user->verification_status == 1) && ($current_ip != $user->verification_ip)) {
                        $verification_key = tep_create_random_value(10, 'digits');

                        $signup_data_array['verification_key'] = $verification_key;
                        $this->user->update($user->user_id, $signup_data_array);

                        $this->load->model('email_model');
                        $this->email_model->sendmail($key, $user_to, $email, $data, $user_from = null);




                        $email_info = get_email_template('VERIFYCATION_KEY');

                        $msg_subject = $email_info['emailtemplate_subject'];
                        $msg_content = str_replace(array('[firstname]', '[verification_key]'), array($user_info['firstname'], $verification_key), $email_info['emailtemplate_content']);
                        $msg_content = html_entity_decode($msg_content);
                        tep_mail($user_info['firstname'] . ' ' . $user_info['lastname'], $user_info['email'], $msg_subject, $msg_content, SITE_NAME, SITE_CONTACT_EMAIL);
                    }

                    redirect(site_url('login/comfirm'));
                }
            } else {
                $error_log_login++;
                $this->session->set_userdata('error_log_login', $error_log_login);
                $this->data['validerrors'] = $this->validator->errors;
            }
        }


        $this->data['error_log_login'] = $error_log_login;
        $this->view('login/index');
    }

    public function comfirm() {
        $login_id = $this->session->userdata('error_log_login');
        if (!$login_id) {
            redirect(site_url('login'));
        }
    }

}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */