<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Home extends MY_Controller {

    public function __construct() {
        parent::__construct();
        $this->data['menu_config'] = $this->menu_config_1;
    }

    public function index() {
        // get newest rates	
        $url = 'http://docs.ookcash.com/api/get_tag_posts/';
        $fields = array(
            'slug' => $this->configs['API_POST_HOMEPAGE']
        );
        $tags = json_decode(curl_get($url, $fields));
        $posts = array();
        foreach ($tags->posts as $post) {
            $data = array(
                'href' => $post->url,
                'title' => $post->title,
                'content' => substr(strip_tags($post->content), 0, 175),
                'thumbnail' => $post->thumbnail,
            );
            $posts[] = $data;
        }
        
        $this->data['posts'] = $posts;

        $post_info_url = 'http://docs.ookcash.com/api/get_page/';
        $post_info_fields = array(
            'slug' => $this->configs['API_POST_BANNER']
        );
        $post_info_object = json_decode(curl_get($post_info_url, $post_info_fields));
        $post_info = array(
            'href' => $post_info_object->page->url,
            'title' => $post_info_object->page->title,
            'content' => $post_info_object->page->content,
        );
        
        $this->data['post_info'] = $post_info;
        
        $this->view('home');
    }

}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */