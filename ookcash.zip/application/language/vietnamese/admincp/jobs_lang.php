<?php

$lang['heading_title'] = 'Công việc';
$lang['btn_add_job'] = 'Thêm Việc';
?>
