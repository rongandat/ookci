<?php

$lang['heading_title'] = 'Việc làm &amp; Tuyển dụng - Jobs in Vietnam';
$lang['text_list_job'] = 'Danh Sách Việc Làm';

$lang['tab_specializations'] = 'Chuyên Ngành';
$lang['tab_locations'] = 'Địa Điểm';
$lang['tab_specializations'] = 'Cấp Bậc';

$lang['text_manufacturer'] = 'Nhà Tuyển Dụng<br> HÀNG ĐẦU';

$lang['btn_login'] = 'Đăng nhập';
$lang['btn_register'] = '<span style="color:#cc0001;">Đăng Ký</span> MIỄN PHÍ';

$lang['text_input_find'] = "Nhập chức danh, vị trí làm việc …";
$lang['text_select_location'] = "Tất cả địa điểm";
$lang['text_top_city'] = "Các thành phố hàng đầu";
$lang['text_select_specialization'] = "Tất cả ngành nghề";
$lang['text_select_position'] = "Tất cả các cấp bậc";
$lang['text_find_enhance'] = "Tìm Kiếm Nâng Cao";
$lang['text_find'] = "Tìm Ngay!";
$lang['text_list_job'] = 'Danh Sách Việc Làm';

?>
