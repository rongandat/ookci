<div class="footer">
    <div class="footer_content">
        <div class="footer_column1">
            <h1>Về JobStreet</h1><br>
            <h2><a href="http://www.jobstreet.vn/aboutus/default.htm">Công Ty</a></h2><br>
            <h2><a href="http://impact-my.jobstreet.com/jobs/jobs.asp?eid=1612&amp;fil=1&amp;did=485">Cơ Hội Nghề Nghiệp</a></h2><br>
            <h2><a href="http://www.jobstreet.vn/aboutus/contact_usVN.htm">Liên Hệ</a></h2><br><br>
            <h1>Đối Tác</h1><br>
            <h2><a target="_blank" href="http://sanook.com/">Sanook.com</a></h2><br>
            <h2><a target="_blank" href="http://asiatravel.com/">Asiatravel.com</a></h2><br>
            <h2><a target="_blank" href="http://www.recruit.com.hk/default.aspx">Recruit - Jobs in Hong Kong</a></h2><br>
            <h2><a target="_blank" href="http://www.104.com.tw/index.htm">104 Corporation - Jobs in Taiwan</a></h2><br>
        </div>
        <div class="footer_column2">
            <h1>Người Tìm Việc</h1><br>
            <h2><a href="http://www.jobstreet.vn/aboutus/terms_use.htm">Điều Khoản Sử Dụng</a></h2><br>
            <h2><a href="http://www.jobstreet.vn/aboutus/privacy_policy.htm">Chính Sách Bảo Mật</a></h2><br>
            <h2><a href="http://www.jobstreet.vn/announcement/2006/s/sus.htm">Hướng Dẫn Tìm Việc An Toàn</a></h2><br>
            <h2><a href="http://myjobstreet.jobstreet.vn/home/help.php?site=vn">Trợ Giúp</a></h2><br><br>
            <h1>Nhà Tuyển Dụng</h1><br>
            <h2><a href="http://www.jobstreet.vn/employers/default.htm">Đăng Tin Tuyển Dụng</a></h2><br>
            <h2><a target="_blank" href="http://siva-vn.jobstreet.com/welcome/enquiry.asp?c=vn">Gửi Yêu Cầu</a></h2><br><br>
        </div>
        <div class="footer_column3">
            <h1>JobStreet Quốc Tế</h1><br>
            <h2><a href="http://www.jobstreet.co.in">Ấn Độ</a></h2><br>
            <h2><a href="http://www.jobstreet.co.id">Indonesia</a></h2><br>
            <h2><a href="http://jp.jobstreet.com">Nhật Bản</a></h2><br>
            <h2><a href="http://www.jobstreet.com.my">Malaysia</a></h2><br>
            <h2><a href="http://www.jobstreet.com.ph">Philippin</a></h2><br>
            <h2><a href="http://www.jobstreet.com.sg">Singapore</a></h2><br>
            <h2><a href="http://www.jobstreet.co.th">Thái Lan</a></h2><br>
            <h2><a href="http://www.jobstreet.vn">Việt Nam</a></h2><br>
        </div>
        <div class="footer_column4">
            <h1>Mobile &amp; Mạng Xã Hội</h1><br>
            <table cellspacing="15" cellpadding="0" border="0" width="200" style="margin-left:-15px; margin-top:-5px;">
                <tbody><tr>
                        <td>
                            <img align="absmiddle" style="padding-right:3px;" src="http://www.jobstreet.vn/hpstc/default/common/img/app.gif">
                            <h2><a href="http://www.jobstreet.vn/mobile-app">Ứng Dụng Cho ĐTDĐ</a></h2><br>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <img align="absmiddle" style="padding-right:3px;" src="http://www.jobstreet.vn/hpstc/default/common/img/facebook.gif">
                            <h2><a target="_blank" href="https://www.facebook.com/JobStreetVN">Facebook</a></h2><br>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <img align="absmiddle" style="padding-right:3px;" src="http://www.jobstreet.vn/hpstc/default/common/img/twitter.gif">
                            <h2><a target="_blank" href="https://twitter.com/JobStreetVN">Twitter</a></h2><br>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <img align="absmiddle" style="padding-right:3px;" src="http://www.jobstreet.vn/hpstc/default/common/img/forum.gif">
                            <h2><a target="_blank" href="http://forum.jobstreet.com">Forum</a></h2><br>
                        </td>
                    </tr>
                </tbody></table>
        </div>
    </div>
    <div class="clear"></div>
    <div class="copyright px10">Copyright &copy; 2013 JobStreet.com</div>
</div>
</body>
</html>
