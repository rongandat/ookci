<br />
<table width="100%" border="0" cellpadding="0" cellspacing="0" >
 <tr>
    <td align="center" valign="middle" class="footerbg">Copyright &copy; 2009  Gwebcash.com. All rights reserved.</td>
    <td>&nbsp;</td>
  </tr>
</table>  