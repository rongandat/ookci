<?php /* Smarty version 2.6.18, created on 2010-02-28 18:55:34
         compiled from home/logout.html */ ?>
<br />
<span class="success"><strong><?php echo $this->_tpl_vars['TEXT_LOGOUT_SUCCESS']; ?>
</strong></span>