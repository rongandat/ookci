<?php
$langs	=	array ('HEADING_TITLE'	=>	'Categories',
					'HEADING_NEW_CATEGORY'	=>	'New Category',
					'HEADING_EDIT_CATEGORY'	=>	'Edit Category',
					'TEXT_SELECT_CATEGORY'	=>	'Select Partent Category:',
					'TABLE_HEADING_CATEGORY_NAME'	=> 'Category Name',
					'TABLE_HREADING_CATEGORY_STATUS'	=> 'Category Status',
					'TABLE_HREADING_CATEGORY_SORT_ORDER'	=>	'Sort Order',						
					'LINK_NEW_CATEGORY'	=>	'Add Category',
					'TEXT_CATEGORY_NAME'	=> 	'Category Name:',
					'TEXT_CATEGORY_SORT_ORDER'	=>	'Sort Order:',
					'TEXT_CATEGORY_STATUS'	=>	'Status:',
					'TEXT_CATEGORY_SHORT_DESC'	=> 'Short Description:',
					'TEXT_CATEGORY_DESCRIPTION'	=> 'Description:',
					'TEXT_DELETE_CONFIRM_MESSAGE'	=>	'Are you sure you want to delete the category?',		
					
			);
			
define('TEXT_MESSAGE_CATEGORIES_DELETED', 'The category have been removed.');
			
?>