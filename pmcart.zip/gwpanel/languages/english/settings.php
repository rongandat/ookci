<?php
$langs	=	array('HEADING_TITLE'=>'Settings',
		'TABLE_HEADING_CONFIG_TITLE'	=> 'Configuration Title',
		'TABLE_HREADING_CONFIG_VALUE'	=> 'Value',
		'TEXT_SELECT_CONFIGURATION_GROUP'=> 'Configuration Group:',
		'TABLE_HREADING_CONFIG_DESC'	=> 'Configuration Description',
		'HEADING_EDIT_TITLE'=>'Edit Configuration Value',
		'TEXT_CONFIGURATION_TITLE'	=> 'Configuration Title:',
		'TEXT_CONFIGURATION_DESC'	=> 'Configuration Description:',
		'TEXT_CONFIGURATION_VALUE'	=> 'Configuration Value:'		
	);
	
define('TEXT_MESSAGE_CONFIGURATION_UPDATED','The configuration have been updated.');	
?>