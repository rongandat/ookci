<?php
$langs	=	array('HEADING_TITLE'=> 'Currencies',
				'HEADING_NEW_CURRENCY'	=>	'Add New Currency',
				'LINK_NEW_CURRENCY'		=> 'Add Currency',
				'HEADING_EDITCURRENCY'	=>	'Edit Currency',
				'HEADER_CURRENCY_NAME'	=>	'Currency Name',
				'HEADER_CURRENCY_CODE'	=> 	'Currency Code',
				'HEADER_CURRENCY_STATUS'	=> 'Status',
				'HEADER_CURRENCY_IMAGE'	=> 'Icon',
				'TEXT_INACTIVE'	=>	'Inactive',
				'TEXT_ACTIVE'	=>	'Active',
				'HEADING_EDIT_TITLE'	=> 	'Edit Currency',
				'TEXT_CURRENCY_NAME'	=>	'Currency Name:',
				'TEXT_CURRENCY_CODE'	=>	'Currency Code:',
				'TEXT_CURRENCY_STATUS'	=> 	'Status:',
				'TEXT_CURRENCY_SORT_ORDER'	=> 	'Sort Order:',
				'TEXT_DELETE_CONFIRM_MESSAGE'	=>	'Are you sure you want to delete the currency?',
				'TEXT_CURRENCY_SYMBOL_LEFT'	=>	'Symbol Left',
				'TEXT_CURRENCY_SYMBOL_RIGHT'	=>	'Symbol Right',				
				'TEXT_CURRENCY_DECIMAL_POINT'	=>	'Decimal Point',
				'TEXT_CURRENCY_THOUSANDS_POINT'	=>	'Thousands Point',				
				'TEXT_CURRENCY_DECIMAL_PLACES'	=>	'Decimal Places',
				'HEADER_CURRENCY_SYMBOL'	=> 'Currency Symbol'
			);
		
define('TEXT_MESSAGE_CURRENCY_DELETED','The currency have been deleted.');		
?>