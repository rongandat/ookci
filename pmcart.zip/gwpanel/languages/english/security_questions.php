<?php
$langs	=	array ('HEADING_TITLE'	=>	'Security Questions',
					'HEADING_NEW_SECURITY_QUESTION'	=>	'New Security Question',
					'HEADING_EDIT_SECURITY_QUESTION'	=>	'Edit Security Question',
					'TABLE_HEADING_SECURITY_QUESTION_NAME'	=> 'Question',
					'TABLE_HREADING_SECURITY_QUESTION_STATUS'	=> 'Security Question Status',
					'TABLE_HREADING_SECURITY_QUESTION_SORT_ORDER'	=>	'Sort Order',						
					'LINK_NEW_SECURITY_QUESTION'	=>	'Add Security Question',
					'TEXT_SECURITY_QUESTION_NAME'	=> 	'Question:',
					'TEXT_SECURITY_QUESTION_SORT_ORDER'	=>	'Sort Order:',
					'TEXT_SECURITY_QUESTION_STATUS'	=>	'Status:',
					'TEXT_DELETE_CONFIRM_MESSAGE'	=>	'Are you sure you want to delete the Security Question?',		
					
			);
			
define('TEXT_MESSAGE_SECURITY_QUESTIONS_DELETED', 'The category have been removed.');
			
?>