<?php /* Smarty version 2.6.18, created on 2013-07-17 16:02:09
         compiled from home/applications.html */ ?>
<div class="simple-form">
    <h1>SCI Guide</h1>
    <p><a href="<?php echo $this->_tpl_vars['general_form_href']; ?>
"><font color="">General form</font></a></p>
    <div class="line"></div>
    <h1>API Guide</h1>
    <p>API: API Guide (Coming soon!)</p>
</div>

