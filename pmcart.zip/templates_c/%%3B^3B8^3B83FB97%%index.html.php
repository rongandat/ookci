<?php /* Smarty version 2.6.18, created on 2013-06-27 11:11:15
         compiled from services/index.html */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('function', 'dev_get_page_link', 'services/index.html', 28, false),)), $this); ?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<div align="right">
    <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="650" id="AutoNumber35" height="445">
        <tr>
            <td width="100%" height="20">&nbsp;</td>
        </tr>
        <tr>
            <td width="100%" height="30" valign="top">
                <font face="Tahoma" size="3" color="#800000"><b>Our Services</b>
                </font></td>
        </tr>
        <tr>
            <td width="100%" valign="top" height="40">
                <blockquote>
                    <font size="2" face="Tahoma">Welcome to our services section. 
                    In this part of our web site you will find the following 
                    services: </font>
                </blockquote>
            </td>
        </tr>
        <tr>
            <td width="100%" valign="top" height="13">
                <div align="center">
                    <center>
                        <table border="0" cellpadding="15" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="580" id="AutoNumber36">
                            <tr>
                                <td width="100%" rowspan="6" bgcolor="#CCCCCC" valign="top">
                                    <form name="frmSearchUser" action="<?php echo smarty_function_dev_get_page_link(array('page' => 'PAGE_SERVICE_SEARCH_USER'), $this);?>
" method="post">
                                        <input name="action" value="process" type="hidden" />		  
                                        <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%" id="AutoNumber37" height="53">
                                            <tr>
                                                <td width="100%" valign="top" height="30"><b>
                                                        <font size="2" face="Tahoma" color="#800000">Account 
                                                        Public Info</font></b></td>
                                            </tr>
                                            <tr>
                                                <td width="100%" valign="top" height="19">
                                                    <font size="2" face="Tahoma">This service will display 
                                                    any available public information of any Global Cash 
                                                    account holder. </font>
                                                    <p><font size="2" face="Tahoma">View public 
                                                        information of any account in our system. To edit your 
                                                        own information please login to your account edit any 
                                                        information about yourself and your account in Profile 
                                                        -&gt; Personal Information and Profile Information</font></p>
                                                    <p align="center"><font size="2" face="Tahoma">Account 
                                                        number : </font>
                                                        <input type="text" name="account_number" size="20"><input type="submit" value="Submit" name="buttonSearchUser">
                                                    <p align="left"><font size="2" face="Tahoma">Enter the 
                                                        code (turing number) shown on the image (Note: If you 
                                                        cannot read the numbers, reload the page to generate a 
                                                        new one): </font></p>
                                                    <div align="center">
                                                        <center>
                                                            <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="350" id="AutoNumber40">
                                                                <tr>
                                                                    <td width="216">
                                                                        <p align="center"><a href="javascript: refreshSecureImage();"><img src="<?php echo smarty_function_dev_get_page_link(array('page' => 'module=secureimage&page=secureimage&load=notrefresh'), $this);?>
"   border="0" id="secure_image"  /></a></td>
                                                                    <td width="134">
                                                                        <input   name="security_code"   class="inputtext" size="6"/>
                                                                    </td>
                                                                </tr>
                                                            </table>
                                                        </center>
                                                    </div>			  
                                                </td>
                                            </tr>
                                        </table>
                                    </form> 
                                </td>
                            </tr>
                        </table>
                    </center>
                </div>
            </td>
        </tr>
        <tr>
            <td width="100%" valign="top" height="30">&nbsp;</td>
        </tr>
        <tr>
            <td width="100%" valign="top" height="12">
                <div align="center">
                    <center>
                        <table border="0" cellpadding="15" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="580" id="AutoNumber38">
                            <tr>
                                <td width="100%" bgcolor="#CCCCCC">
                                    <form name="frmRemind" action="<?php echo smarty_function_dev_get_page_link(array('page' => 'PAGE_ACCOUNT_REMIND'), $this);?>
" method="post" >
                                        <input name="action" value="process" type="hidden" />
                                        <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%" id="AutoNumber39">
                                            <tr>
                                                <td width="100%" height="30" valign="top"><b>
                                                        <font size="2" face="Tahoma" color="#800000">Account 
                                                        Number Reminder</font></b></td>
                                            </tr>
                                            <tr>
                                                <td width="100%"><font size="2" face="Tahoma">This 
                                                    service will e-mail you your account number in case 
                                                    you have forgotten it. </font>
                                                    <p><font face="Tahoma" size="2">Use this form if you 
                                                        have forgotten your account number, but you know your 
                                                        e-mail address. Please input your e-mail address in 
                                                        the field below and click Send and your account number 
                                                        will be sent via e-mail. <br>
                                                        Please add admin@e-globalcash.com to your email address 
                                                        book in order to guarantee the delivery of our emails 
                                                        to your inbox. </font></p>
                                                    <p align="center"><font size="2" face="Tahoma">Your 
                                                        Email : </font><input  name="email" type="text"  value="<?php echo $this->_tpl_vars['email']; ?>
"  class="inputtext" size="20"  /><input type="submit" value="Submit" name="B1"></p>
                                                    <p align="left"><font size="2" face="Tahoma">Enter the 
                                                        code (turing number) shown on the image (Note: If you 
                                                        cannot read the numbers, reload the page to generate a 
                                                        new one): </font></p>
                                                    <div align="center">
                                                        <center>
                                                            <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="350" id="AutoNumber40">
                                                                <tr>
                                                                    <td width="216">
                                                                        <p align="center"><a href="javascript: refreshSecureImage();"><img src="<?php echo smarty_function_dev_get_page_link(array('page' => 'module=secureimage&page=secureimage&load=notrefresh&reload=1'), $this);?>
"   border="0" id="secure_image"  /></a></td>
                                                                    <td width="134">
                                                                        <input   name="security_code"   class="inputtext" size="6"/>
                                                                    </td>
                                                                </tr>
                                                            </table>
                                                        </center>
                                                    </div>
                                                </td>
                                            </tr>
                                        </table>
                                    </form>
                                </td>
                            </tr>
                        </table>
                    </center>
                </div>
            </td>
        </tr>
        <tr>
            <td width="100%" valign="top" height="30">&nbsp;</td>
        </tr>
        <tr>
            <td width="100%" valign="top" height="3">
                <div align="center">
                    <center>
                        <table border="0" cellpadding="15" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="580" id="AutoNumber41" bgcolor="#CCCCCC">
                            <tr>
                                <td width="100%">
                                    <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%" id="AutoNumber42">
                                        <tr>
                                            <td width="100%" height="30" valign="top"><b>
                                                    <font size="2" face="Tahoma" color="#800000">
                                                    Transaction Finder</font></b></td>
                                        </tr>
                                        <tr>
                                            <td width="100%"><font size="2" face="Tahoma">This 
                                                form finds the specified transfer if it exists. </font>
                                                <table class="text">
                                                    <tr>
                                                        <td colSpan="2"><font size="2" face="Tahoma">
                                                            Please use this form to confirm if a certain 
                                                            transfer took place, in case you want to be sure 
                                                            that it was successful. <br>
                                                            &nbsp;</font></td>
                                                    </tr>
                                                    <tr>
                                                        <td><font size="2" face="Tahoma">Date of Transfer
                                                            </font></td>
                                                        <td><font face="Tahoma">
                                                            <select id="ctl00_cp1_dpDate_dlDay0" class="form" name="ctl00$cp1$dpDate$dlDay">
                                                                <option selected value="0">--</option>
                                                                <option value="1">1</option>
                                                                <option value="2">2</option>
                                                                <option value="3">3</option>
                                                                <option value="4">4</option>
                                                                <option value="5">5</option>
                                                                <option value="6">6</option>
                                                                <option value="7">7</option>
                                                                <option value="8">8</option>
                                                                <option value="9">9</option>
                                                                <option value="10">10</option>
                                                                <option value="11">11</option>
                                                                <option value="12">12</option>
                                                                <option value="13">13</option>
                                                                <option value="14">14</option>
                                                                <option value="15">15</option>
                                                                <option value="16">16</option>
                                                                <option value="17">17</option>
                                                                <option value="18">18</option>
                                                                <option value="19">19</option>
                                                                <option value="20">20</option>
                                                                <option value="21">21</option>
                                                                <option value="22">22</option>
                                                                <option value="23">23</option>
                                                                <option value="24">24</option>
                                                                <option value="25">25</option>
                                                                <option value="26">26</option>
                                                                <option value="27">27</option>
                                                                <option value="28">28</option>
                                                                <option value="29">29</option>
                                                                <option value="30">30</option>
                                                                <option value="31">31</option>
                                                            </select></font><font size="2" face="Tahoma">
                                                            </font><font face="Tahoma">
                                                            <select id="ctl00_cp1_dpDate_dlMonth0" class="form" name="ctl00$cp1$dpDate$dlMonth">
                                                                <option selected value="0">--</option>
                                                                <option value="1">1</option>
                                                                <option value="2">2</option>
                                                                <option value="3">3</option>
                                                                <option value="4">4</option>
                                                                <option value="5">5</option>
                                                                <option value="6">6</option>
                                                                <option value="7">7</option>
                                                                <option value="8">8</option>
                                                                <option value="9">9</option>
                                                                <option value="10">10</option>
                                                                <option value="11">11</option>
                                                                <option value="12">12</option>
                                                            </select></font><font size="2" face="Tahoma">
                                                            </font><font face="Tahoma">
                                                            <select id="ctl00_cp1_dpDate_dlYear0" class="form" name="ctl00$cp1$dpDate$dlYear">
                                                                <option selected value="0">--</option>
                                                                <option value="2005">2005</option>
                                                                <option value="2006">2006</option>
                                                                <option value="2007">2007</option>
                                                                <option value="2008">2008</option>
                                                                <option value="2009">2009</option>
                                                                <option value="2010">2010</option>
                                                            </select></font><font size="2" face="Tahoma">
                                                            </font></td>
                                                    </tr>
                                                    <tr>
                                                        <td><font size="2" face="Tahoma">Source Account<font color="#FF0000">
                                                            </font>
                                                            <span style="VISIBILITY: hidden; COLOR: red; FONT-WEIGHT: bold" id="ctl00_cp1_reqSource0" controltovalidate="ctl00_cp1_tbSender" errormessage="*" initialvalue isvalid="true" validationGroup="FindTransaction">
                                                                *</span><font color="#FF0000"> </font></font></td>
                                                        <td><font face="Tahoma">
                                                            <input id="ctl00_cp1_tbSender0" class="form" name="ctl00$cp1$tbSender" size="20"></font><font size="2" face="Tahoma">
                                                            </font></td>
                                                    </tr>
                                                    <tr>
                                                        <td><font size="2" face="Tahoma">Destination 
                                                            Account<font color="#FF0000"> </font>
                                                            <span style="VISIBILITY: hidden; COLOR: red; FONT-WEIGHT: bold" id="ctl00_cp1_reqDest0" controltovalidate="ctl00_cp1_tbReceiver" errormessage="*" initialvalue isvalid="true" validationGroup="FindTransaction">
                                                                *</span><font color="#FF0000"> </font></font></td>
                                                        <td><font face="Tahoma">
                                                            <input id="ctl00_cp1_tbReceiver0" class="form" name="ctl00$cp1$tbReceiver" size="20"></font><font size="2" face="Tahoma">
                                                            </font></td>
                                                    </tr>
                                                    <tr>
                                                        <td><font size="2" face="Tahoma">Batch<font color="#FF0000">
                                                            </font>
                                                            <span style="VISIBILITY: hidden; COLOR: red; FONT-WEIGHT: bold" id="ctl00_cp1_reqBatch0" controltovalidate="ctl00_cp1_tbBatch" errormessage="*" initialvalue isvalid="true" validationGroup="FindTransaction">
                                                                *</span><font color="#FF0000"> </font></font></td>
                                                        <td><font face="Tahoma">
                                                            <input id="ctl00_cp1_tbBatch0" class="form" name="ctl00$cp1$tbBatch" size="20"></font><font size="2" face="Tahoma">
                                                            </font></td>
                                                    </tr>
                                                    <tr>
                                                        <td><font size="2" face="Tahoma">Currency </font>
                                                        </td>
                                                        <td><font face="Tahoma">
                                                            <select id="ctl00_cp1_dlCurr0" class="form" name="ctl00$cp1$dlCurr">
                                                                <option selected value="1">USD</option>
                                                                <option value="2">Euro</option>
                                                                <option value="3">GBP</option>
                                                                <option value="4">Gold</option>
                                                            </select></font><font size="2" face="Tahoma">
                                                            </font></td>
                                                    </tr>
                                                    <tr>
                                                        <td><font size="2" face="Tahoma">Amount<font color="#FF0000">
                                                            </font>
                                                            <span style="VISIBILITY: hidden; COLOR: red; FONT-WEIGHT: bold" id="ctl00_cp1_reqAmount0" controltovalidate="ctl00_cp1_tbAmount" errormessage="*" initialvalue isvalid="true" validationGroup="FindTransaction">
                                                                *</span><font color="#FF0000"> </font></font></td>
                                                        <td><font face="Tahoma">
                                                            <input id="ctl00_cp1_tbAmount0" class="form" name="ctl00$cp1$tbAmount" size="20"></font><font size="2" face="Tahoma">
                                                            </font></td>
                                                    </tr>
                                                </table>
                                                <p align="center">
                                                <input type="submit" value="Submit" name="B1"></td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>
                    </center>
                </div>
            </td>
        </tr>
    </table>
</div>
<div align="right">
    <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="650" id="AutoNumber43">
        <tr>
            <td width="100%" height="80">&nbsp;</td>
        </tr>
    </table>
</div>