<?php /* Smarty version 2.6.18, created on 2012-06-03 06:01:30
         compiled from home/faq.html */ ?>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <div align="right">
	<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="650" id="AutoNumber35">
	  <tr>
		<td width="100%" height="20">&nbsp;</td>
	  </tr>
	  <tr>
		<td width="100%" height="50" valign="top">
			<font face="Tahoma" size="3" color="#800000"><a name="FAQ"><b>FAQ</b>
			</a>
			</font></td>
	  </tr>
	  </table>
  </div>
  <div align="center">
	<center>
	<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="580" id="AutoNumber36" height="412">
	  <tr>
		<td width="100%" height="291">
		<ul>
		  <li><font face="Tahoma" size="2">
		  <a href="#How do I protect my account from being accessed by unauthorized users">
		  How do I protect my account from being accessed by 
		  unauthorized users? </a></font></li>
		  <li><font face="Tahoma" size="2">
		  <a href="#Am I allowed to have multiple GwebCash accounts">Am 
		  I allowed to have multiple Global Cash accounts? </a></font></li>
		  <li><font face="Tahoma" size="2">
		  <a href="#Now that I opened my GwebCash account, how do I put funds into it">Now that I opened my Global Cash
		  account, how do I put funds into 
		  it?</a> </font></li>
		  <li><font face="Tahoma" size="2">
		  <a href="#How do I convert Liberty Reserve, Pecunix, or Webmoney into GwebCash">How do I convert Liberty Reserve, Pecunix, or Webmoney into Global Cash?</a> </font></li>
		  <li><font face="Tahoma" size="2">
		  <a href="#I have USD in my account and I need it to be converted to Euro or other currensy. How do I go about this">
		  I have USD in my account and I need it to be converted to Euro 
		  or other currency. How do I go about this? </a></font></li>
		  <li><font face="Tahoma" size="2">
		  <a href="#Which is the fastest, the most trustworthy and the cheapest exchange provider">
		  Which is the fastest, the most trustworthy and the cheapest 
		  exchange provider?</a> </font></li>
		  <li><font face="Tahoma" size="2">
		  <a href="#What is an Exchange Provider How do I work with an Exchange Provider to fund">
		  What is an Exchange Provider? How do I work with an Exchange 
		  Provider to fund</a> </font></li>
		  <li><font face="Tahoma" size="2">
		  <a href="#I have not received my verification e-mail or any other e-mail">
		  I have not received my verification e-mail or any other e-mail</a>
		  </font></li>
		  <li><font face="Tahoma" size="2">
		  <a href="#I would like to change my e-mail address but the PROFILE form does not allow this. What should I do">
		  I would like to change my e-mail address but the PROFILE form 
		  does not allow this. What should I do?</a> </font></li>
		  <li><font face="Tahoma" size="2">
		  <a href="#I have made a mistake in my date of birth. What can I do about it">
		  I have made a mistake in my date of birth. What can I do about 
		  it?</a> </font></li>
		  <li><font face="Tahoma" size="2">
		  <a href="#Someone claims to have sent a payment to my account but funds do not appear in my account history or in my account balance. What is wrong">
		  Someone claims to have sent a payment to my account but funds 
		  do not appear in my account history or in my account balance. 
		  What is wrong?</a> </font></li>
		  <li><font face="Tahoma" size="2">
		  <a href="#The company lists your logo or announces that they are working with GwebCash. Can this be verified in any way">The company lists your logo or announces that they are working 
		  with Global Cash. Can this be verified in any way? </a> </font>
		  </li>
		</ul>
		</td>
	  </tr>
	  <tr>
		<td width="100%" height="121" valign="top">
		<blockquote>
		  <p align="center"><font face="Tahoma" size="2">
		  <a href="http://www.e-globalcash.com/index.php?page=contact&appsid=7d29305e2921f6b06fdc919002e4dee4">Ask your question from here</a></font></p>
		</blockquote>
		</td>
	  </tr>
	</table>
	</center>
  </div>
  <div align="center">
	<center>
	<table border="0" cellpadding="10" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="580" id="AutoNumber37" height="114">
	  <tr>
		<td width="100%" bgcolor="#C0C0C0"><b>
		<font face="Tahoma" size="2">
		<a name="How do I protect my account from being accessed by unauthorized users">
		How do I protect my account from being accessed by unauthorized 
		users? </a></font></b></td>
	  </tr>
	  <tr>
		<td width="100%" height="19">
		<ol>
		  <li><font size="2" face="Tahoma">Create unique passwords</font></li>
		  <li><font size="2" face="Tahoma">Never give out your passwords</font></li>
		  <li><font size="2" face="Tahoma">Always access with a trusted 
		  computer, with an updated anti-virus software installed.</font></li>
		  <li><font size="2" face="Tahoma">Never click on a link in an 
		  email, even if it came from your friend.</font></li>
		  <li><font size="2" face="Tahoma">Send us an email if you 
		  suspect a fake email or a fake web site. </font></li>
		</ol>
		</td>
	  </tr>
	  <tr>
		<td width="100%">
		<p align="right"><b><font size="2" face="Tahoma"><a href="#FAQ">
		Go to Top</a></font></b></td>
	  </tr>
	  <tr>
		<td width="100%" height="30">&nbsp;</td>
	  </tr>
	  <tr>
		<td width="100%" bgcolor="#C0C0C0"><b>
		<font face="Tahoma" size="2">
		<a name="Am I allowed to have multiple GwebCash accounts">Am I 
		allowed to have multiple Global Cash accounts? </a></font></b></td>
	  </tr>
	  <tr>
		<td width="100%" height="10">
		<p align="left"><font face="Tahoma" size="2">Yes. You may open 
		as many Global Cash account as you wish as long as each account has its 
		own unique e-mail address. </font></td>
	  </tr>
	  <tr>
		<td width="100%">
		<p align="right"><b><font size="2" face="Tahoma"><a href="#FAQ">
		Go to Top</a></font></b></td>
	  </tr>
	  <tr>
		<td width="100%" height="30">&nbsp;</td>
	  </tr>
	  <tr>
		<td width="100%" bgcolor="#C0C0C0">
		<p align="left"><b><font face="Tahoma" size="2">
		<a name="Now that I opened my GwebCash account, how do I put funds into it">
		Now that I opened my Global Cash account, how do I put funds into 
		it? </a></font></b></td>
	  </tr>
	  <tr>
		<td width="100%" height="1"><font face="Tahoma" size="2">You may 
		receive payments to your account from other users or you may 
		fund your account using the services of our
        <a href="http://www.e-globalcash.net/index.php?page=exchangers&appsid=7d29305e2921f6b06fdc919002e4dee4">global network of exchange providers</a> 
		that would be happy to exchange your national currency </font>
		</td>
	  </tr>
	  <tr>
		<td width="100%">
		<p align="right"><b><font size="2" face="Tahoma"><a href="#FAQ">
		Go to Top</a></font></b></td>
	  </tr>
	  <tr>
		<td width="100%" height="30">&nbsp;</td>
	  </tr>
	  <tr>
		<td width="100%" bgcolor="#C0C0C0"><b>
		<font face="Tahoma" size="2">
		<a name="How do I convert Liberty Reserve, Pecunix, or Webmoney into GwebCash">
		How do I convert Liberty Reserve, Pecunix, or Webmoney into 
		Global Cash? </a></font></b></td>
	  </tr>
	  <tr>
		<td width="100%" height="1">
		<p align="left"><font face="Tahoma" size="2">
		<a href="http://www.e-globalcash.net/index.php?page=exchangers&appsid=7d29305e2921f6b06fdc919002e4dee4">Our exchange providers</a> are more 
		than happy to exchange your funds stored in a different payment 
		system and put them into your account</font></td>
	  </tr>
	  <tr>
		<td width="100%" height="0">
		<p align="right"><b><font size="2" face="Tahoma"><a href="#FAQ">
		Go to Top</a></font></b></td>
	  </tr>
	  <tr>
		<td width="100%" height="30">&nbsp;</td>
	  </tr>
	  <tr>
		<td width="100%" bgcolor="#C0C0C0">
		<p align="left"><b><font face="Tahoma" size="2">
		<a name="I have USD in my account and I need it to be converted to Euro or other currensy. How do I go about this">
		I have USD in my account and I need it to be converted to Euro 
		or other currency. How do I go about this? </a></font></b></td>
	  </tr>
	  <tr>
		<td width="100%" height="1">
		<p align="left"><font face="Tahoma" size="2">Please note that 
		you can not exchange Global Cash USD and Global Cash EURO or any other 
		currencies inside of your Global Cash account. You need to purchase 
		each currency separately or exchange it through one of the 
		independent exchange providers listed in
        <a href="http://www.e-globalcash.net/index.php?page=exchangers&appsid=7d29305e2921f6b06fdc919002e4dee4">our exchangers list</a>.</font></td>
	  </tr>
	  <tr>
		<td width="100%" height="0">
		<p align="right"><b><font size="2" face="Tahoma"><a href="#FAQ">
		Go to Top</a></font></b></td>
	  </tr>
	  <tr>
		<td width="100%" height="30">&nbsp;</td>
	  </tr>
	  <tr>
		<td width="100%" bgcolor="#C0C0C0">
		<p align="left"><b><font face="Tahoma" size="2">
		<a name="Which is the fastest, the most trustworthy and the cheapest exchange provider">
		Which is the fastest, the most trustworthy and the cheapest 
		exchange provider? </a></font></b></td>
	  </tr>
	  <tr>
		<td width="100%" height="0">
		<p align="left"><font face="Tahoma" size="2">You can find a list 
		of established and professional exchange providers on the
        <a href="http://www.e-globalcash.net/index.php?page=exchangers&appsid=7d29305e2921f6b06fdc919002e4dee4">&quot;Exchangers&quot; page</a>.</font></td>
	  </tr>
	  <tr>
		<td width="100%" height="0">
		<p align="right"><b><font size="2" face="Tahoma"><a href="#FAQ">
		Go to Top</a></font></b></td>
	  </tr>
	  <tr>
		<td width="100%" height="30">&nbsp;</td>
	  </tr>
	  <tr>
		<td width="100%" height="0" bgcolor="#C0C0C0">
		<p align="left"><b><font face="Tahoma" size="2">
		<a name="What is an Exchange Provider How do I work with an Exchange Provider to fund">
		What is an Exchange Provider? How do I work with an Exchange 
		Provider to fund </a></font></b></td>
	  </tr>
	  <tr>
		<td width="100%" height="0">
		<p align="left"><font face="Tahoma" size="2">An
        <a href="http://www.e-globalcash.net/index.php?page=exchangers&appsid=7d29305e2921f6b06fdc919002e4dee4">exchanger</a> is a person or company 
		who, for a fee, exchanges cash, credit cards and a variety of 
		other items (i.e. other digital or electronic currencies) into 
		the type of currency requested by an individual or company. 
		Remember that each
        <a href="http://www.e-globalcash.net/index.php?page=exchangers&appsid=7d29305e2921f6b06fdc919002e4dee4">exchanger listed</a> 
		is an independently owned and operated business. They each have 
		their own sets of policies, procedures, fees and funding methods 
		to meet their market demand. They are also located and serve 
		various jurisdictions in various countries. You should do your 
		own due diligence to determine which exchanger will best fit 
		your needs relating to funding options.</font></td>
	  </tr>
	  <tr>
		<td width="100%" height="0">
		<p align="right"><b><font size="2" face="Tahoma"><a href="#FAQ">
		Go to Top</a></font></b></td>
	  </tr>
	  <tr>
		<td width="100%" height="30">&nbsp;</td>
	  </tr>
	  <tr>
		<td width="100%" height="0" bgcolor="#C0C0C0">
		<p align="left"><b><font face="Tahoma" size="2">
		<a name="I have not received my verification e-mail or any other e-mail">
		I have not received my verification e-mail or any other e-mail
		</a></font></b></td>
	  </tr>
	  <tr>
		<td width="100%" height="0">
		<p align="left"><font face="Tahoma" size="2">Please check your 
		SPAM/Junk e-mail folders.</font></td>
	  </tr>
	  <tr>
		<td width="100%" height="0">
		<p align="right"><b><font size="2" face="Tahoma"><a href="#FAQ">
		Go to Top</a></font></b></td>
	  </tr>
	  <tr>
		<td width="100%" height="30">&nbsp;</td>
	  </tr>
	  <tr>
		<td width="100%" height="0" bgcolor="#C0C0C0">
		<font face="Tahoma" size="2"><b>
		<a name="I would like to change my e-mail address but the PROFILE form does not allow this. What should I do">
		I would like to change my e-mail address but the PROFILE form 
		does not allow this. What should I do? </a></b></font></td>
	  </tr>
	  <tr>
		<td width="100%" height="0">
		<p align="left"><font face="Tahoma" size="2">E-mail addresses 
		can not be updated by users themselves for security reasons.
		</font></td>
	  </tr>
	  <tr>
		<td width="100%" height="0">
		<p align="right"><b><font size="2" face="Tahoma"><a href="#FAQ">
		Go to Top</a></font></b></td>
	  </tr>
	  <tr>
		<td width="100%" height="30">&nbsp;</td>
	  </tr>
	  <tr>
		<td width="100%" height="0" bgcolor="#C0C0C0">
		<p align="left"><b><font face="Tahoma" size="2">
		<a name="I have made a mistake in my date of birth. What can I do about it">
		I have made a mistake in my date of birth. What can I do about 
		it? </a></font></b></td>
	  </tr>
	  <tr>
		<td width="100%" height="0">
		<p align="left"><font face="Tahoma" size="2">Date of birth is 
		used for verification purposes and can not be updated.</font></td>
	  </tr>
	  <tr>
		<td width="100%" height="0">
		<p align="right"><b><font size="2" face="Tahoma"><a href="#FAQ">
		Go to Top</a></font></b></td>
	  </tr>
	  <tr>
		<td width="100%" height="30">&nbsp;</td>
	  </tr>
	  <tr>
		<td width="100%" height="0" bgcolor="#C0C0C0">
		<p align="left"><b><font face="Tahoma" size="2">
		<a name="Someone claims to have sent a payment to my account but funds do not appear in my account history or in my account balance. What is wrong">
		Someone claims to have sent a payment to my account but funds do 
		not appear in my account history or in my account balance. What 
		is wrong? </a></font></b></td>
	  </tr>
	  <tr>
		<td width="100%" height="0">
		<p align="left"><font face="Tahoma" size="2">Please note that 
		all payments between account holders are instantaneous. Every 
		time the payment is made a unique transfer batch number is 
		generated and is displayed in your account history. Account 
		holders can provide this number to each other as proof of their 
		payment. Please note, that if company refuses to provide you 
		with the transfer batch number or provides you with the fake one 
		- the payment, most likely, was never made.</font></td>
	  </tr>
	  <tr>
		<td width="100%" height="0">
		<p align="right"><b><font size="2" face="Tahoma"><a href="#FAQ">
		Go to Top</a></font></b></td>
	  </tr>
	  <tr>
		<td width="100%" height="30">&nbsp;</td>
	  </tr>
	  <tr>
		<td width="100%" height="0" bgcolor="#C0C0C0">
		<p align="left"><b><font face="Tahoma" size="2">
		<a name="The company lists your logo or announces that they are working with GwebCash. Can this be verified in any way">
		The company lists your logo or announces that they are working 
		with Global Cash. Can this be verified in any way? </a></font></b>
		</td>
	  </tr>
	  <tr>
		<td width="100%" height="0">
		<p align="left"><font face="Tahoma" size="2">Any such claim is 
		FALSE. Please note that Global Cash is owned and operated 
		independently of any other business or company. If you have any 
		questions about performance of a certain company or about any 
		products and services that they offer - you need to contact that 
		company directly. The mere fact that a vendor chooses to accept 
		on his web site as a form of payment does not add legitimacy or 
		credibility to any business entity. </font></td>
	  </tr>
	  <tr>
		<td width="100%" height="0">
		<p align="right"><b><font size="2" face="Tahoma"><a href="#FAQ">
		Go to Top</a></font></b></td>
	  </tr>
	</table>
	</center>
  </div>
  <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%" id="AutoNumber14" height="58">
	<tr>
	  <td width="100%" height="58">&nbsp;</td>
	</tr>
  </table>