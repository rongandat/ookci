<?php /* Smarty version 2.6.18, created on 2010-02-25 20:20:08
         compiled from home/account.html */ ?>
<table cellpadding="2" cellspacing="2" border="0" width="100%" >
	<tr> <td  class="pageHeading">Account</td></tr>
	<tr><td><?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'home/modules/account_header.html', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?></td></tr>
	
</table>
<br />
<table cellpadding="0" cellspacing="0" border="0" class="form_content">
<tr><td valign="top" width="50%">
	<table cellpadding="0" cellspacing="0" border="0"   width="100%" >
		<tr><td ><span class="contentTitle3">Summary</span></td> </tr>			
	</table>
</td><td valign="top"   width="50%">
	<table cellpadding="0" cellspacing="0" border="0"  width="100%" >
		<tr><td><span class="contentTitle3">Balances</span></td></tr>
	</table>	
</td></tr>
</table>