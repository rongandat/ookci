<?php /* Smarty version 2.6.18, created on 2013-07-19 07:05:21
         compiled from home/reset_password_success.html */ ?>

<div class="simple-form">
    <h1>Account Reset Succeeded</h1>
    <div class="line"></div>
    <div class="success">Thank you. Your account access info has been successfully changed. Please use new credentials to login to your account.</div>
</div>