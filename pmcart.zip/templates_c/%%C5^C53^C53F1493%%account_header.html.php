<?php /* Smarty version 2.6.18, created on 2013-07-18 16:08:27
         compiled from account/modules/account_header.html */ ?>
