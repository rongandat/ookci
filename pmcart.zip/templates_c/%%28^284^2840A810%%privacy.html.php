<?php /* Smarty version 2.6.18, created on 2012-03-05 02:53:58
         compiled from home/privacy.html */ ?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<div align="right">
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="650" id="AutoNumber35">
  <tr>
	<td width="100%" height="20">&nbsp;</td>
  </tr>
  <tr>
	<td width="100%" height="50" valign="top">
		<font face="Tahoma" size="3" color="#800000"><b>e-globalcash 
		Privacy and Confidentiality Policy</b>
		</font></td>
  </tr>
  </table>
</div>
<div align="center">
<center>
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="600" id="AutoNumber36">
  <tr>
	<td width="100%">
	<ul>
	  <li>
	  <p align="left"><font size="2" face="Tahoma">1. e-globalcash 
	  recognizes the User right to confidentiality and privacy.<br>
&nbsp;</font></li>
	  <li>
	  <p align="left"><font size="2" face="Tahoma">1.2 Unless 
	  ordered by a ruling body of competent jurisdiction acceptable 
	  to Issuer, Issuer shall not reveal User contact or 
	  identifying information or transaction history to any third 
	  party.<br>
&nbsp;</font></li>
	  <li>
	  <p align="left"><font size="2" face="Tahoma">1.3 Issuer will 
	  ensure that User has the ability to examine User contact and 
	  identifying information and make updates and changes when 
	  necessary.<br>
&nbsp;</font></li>
	  <li>
	  <p align="left"><font size="2" face="Tahoma">1.4 Issuer will 
	  not store any User details, including but not limited to 
	  account history, contact or identifying information, or 
	  Personal Identification Number(s) in unencrypted plain text 
	  under any circumstances.<br>
&nbsp;</font></li>
	  <li>
	  <p align="left"><font size="2" face="Tahoma">1.5 User agrees 
	  that e-globalcash has the right to monitor the e-globalcash Network 
	  electronically from time to time in order to operate the 
	  System properly.</font></li>
	</ul>
	</td>
  </tr>
</table>
</center>
</div>
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%" id="AutoNumber14">
<tr>
  <td width="100%">&nbsp;</td>
</tr>
</table>