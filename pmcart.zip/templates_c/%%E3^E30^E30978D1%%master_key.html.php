<?php /* Smarty version 2.6.18, created on 2013-07-15 10:19:34
         compiled from account/settings/master_key.html */ ?>
<form name="frmPersonal" method="post" action="<?php echo $this->_tpl_vars['HREF_PAGE']; ?>
"  >
    <input type="hidden" name="action" value="process"  />
    <div align="center">
        <center>
            <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="580" id="AutoNumber36" height="136">
                <tr>
                    <td width="138" valign="top" height="32">
                        <p align="center">
                        <font size="2" face="Tahoma"><font color="#FF0000">*</font>Master Key:</font></td>
                    <td width="442" valign="top" height="32"><font face="Tahoma">
                        <input class="inputtext" type="password" name="master_key" size="5" maxlength="3"</font></td>
                </tr>  
            </table>
            <table border="0" cellSpacing="2" cellPadding="2" width="100%">
                <tr>
                    <td class="contenButtons" align="middle">
                        <input class="button" value="Next" type="submit" name="buttonNext"></td>
                </tr>
            </table>
        </center>
    </div>
</form>