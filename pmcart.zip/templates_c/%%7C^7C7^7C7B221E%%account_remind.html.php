<?php /* Smarty version 2.6.18, created on 2013-07-21 16:10:48
         compiled from home/account_remind.html */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('function', 'dev_get_page_link', 'home/account_remind.html', 1, false),)), $this); ?>
<form name="frmRemind" action="<?php echo smarty_function_dev_get_page_link(array('page' => 'PAGE_ACCOUNT_REMIND','ssl' => true), $this);?>
" method="post" >
    <input name="action" value="process" type="hidden" />
    <div class="simple-form">
        <h1> Account Number Reminder</h1>
        <p>Use this form if you have forgotten your account number, but you know your e-mail address. Please input your e-mail address in the field below and click Send and your account number will be sent via e-mail.</p>
        <div class="line"></div>
        <div class="clear"></div>
        <?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => ($this->_tpl_vars['_TEMPLATE_SOURCE_DIR'])."/modules/validate_error.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
        <table class="form">

            <tr>
                <td class="form_label"><i>*</i>Email:</td>
                <td class="form_field">
                    <input  name="email" type="text"  value="<?php echo $this->_tpl_vars['email']; ?>
"  class="inputtext" size="20"  /></td>
            </tr>	
            <tr> <td >
                    <strong>Enter the code (turing number) shown on the image</strong>	
                    <br />Cannot read the numbers? Click on it to get a new one.
                </td>
                <td>
                    <a href="javascript: refreshSecureImage();"><img src="<?php echo smarty_function_dev_get_page_link(array('page' => 'PAGE_SECUREIMAGE','ssl' => true), $this);?>
"   border="0" id="secure_image" /></a><br />

                    <input   name="security_code"   class="inputtext" size="20"/><br/>
                    <a  href="<?php echo smarty_function_dev_get_page_link(array('page' => 'PAGE_CONTACT_US','ssl' => true), $this);?>
" class="link">Cannot see Turing number at all?</a>

                </td>
            </tr>
            <tr >
                <td></td>
                <td >
                    <input  type="submit" name="buttonSend" class="button"  value="Send" /></td></tr>
        </table>	
    </div>

</form>