<?php /* Smarty version 2.6.18, created on 2013-07-21 16:05:36
         compiled from account/public.html */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('function', 'dev_get_page_link', 'account/public.html', 1, false),array('function', 'dev_get_state_name', 'account/public.html', 54, false),array('function', 'dev_get_country_name', 'account/public.html', 54, false),array('modifier', 'date_format', 'account/public.html', 35, false),)), $this); ?>
<form name="frmLogin" action="<?php echo smarty_function_dev_get_page_link(array('page' => 'PAGE_ACCOUNT_PUBLIC','ssl' => true), $this);?>
" method="post" >
    <input name="action" value="process" type="hidden" />
    <div class="simple-form">
        <h1> Account Public Settings </h1>
        <p>Global Cash have a this function so that you can allow your account information be public and searchable.</p>
        <div class="line"></div>
        <div class="clear"></div>
        <?php if ($this->_tpl_vars['updated']): ?>
        <div class="success">Your settings have been saved.</div>
        <?php endif; ?>

        <table class="form">
            <tr>
                <td width="138" >
                    Account Name:</td>
                <td >
                    <strong><?php echo $this->_tpl_vars['account_info']['account_name']; ?>
</strong></td>
            </tr>
            <tr>
                <td  >
                    Account Type:</td>
                <td  > 
                    <strong><?php if ($this->_tpl_vars['account_info']['account_type'] == 'user'): ?>User<?php endif; ?></strong></td>
            </tr>
            <tr>
                <td  >
                    Account Number:</td>
                <td  > 
                    <strong><?php echo $this->_tpl_vars['account_info']['account_number']; ?>
</strong></td>
            </tr>			  			  
            <tr>
                <td  >
                    Created on:</td>
                <td  > 
                    <strong><?php echo ((is_array($_tmp=$this->_tpl_vars['account_info']['signup_date'])) ? $this->_run_mod_handler('date_format', true, $_tmp, "%m/%d/%Y %l:%M %p") : smarty_modifier_date_format($_tmp, "%m/%d/%Y %l:%M %p")); ?>
</strong></td>
            </tr>	

            <tr>
                <td width="138" ><input type="checkbox" name="name" value="1" <?php if ($this->_tpl_vars['name']): ?> checked="checked"<?php endif; ?>/>
                    Full Name:</td>
                <td >
                    <?php echo $this->_tpl_vars['account_info']['firstname']; ?>
 <?php echo $this->_tpl_vars['account_info']['lastname']; ?>
</td>
            </tr>
            <tr>
                <td  ><input type="checkbox" name="email" value="1" <?php if ($this->_tpl_vars['email']): ?> checked="checked"<?php endif; ?>/>
                    E-mail:</td>
                <td  > 
                    <?php echo $this->_tpl_vars['account_info']['email']; ?>
</td>
            </tr>
            <tr>
                <td  >
                    <input type="checkbox" name="address" value="1" <?php if ($this->_tpl_vars['address']): ?> checked="checked"<?php endif; ?>/> Address:</td>
                <td  > 
                    <?php echo $this->_tpl_vars['account_info']['address']; ?>
,<?php echo $this->_tpl_vars['account_info']['city']; ?>
 <?php echo $this->_tpl_vars['account_info']['postcode']; ?>
 <?php echo smarty_function_dev_get_state_name(array('state' => $this->_tpl_vars['account_info']['state']), $this);?>
 <?php echo smarty_function_dev_get_country_name(array('country' => $this->_tpl_vars['account_info']['country']), $this);?>
</td>
            </tr>			
            <tr>
                <td  ><input type="checkbox" name="company" value="1" <?php if ($this->_tpl_vars['company']): ?> checked="checked"<?php endif; ?>/>
                    Company:</td>
                <td  > 
                    <?php echo $this->_tpl_vars['account_info']['company']; ?>
</td>
            </tr>					    			  
            <tr>
                <td  ><input type="checkbox" name="phone" value="1" <?php if ($this->_tpl_vars['phone']): ?> checked="checked"<?php endif; ?>/>
                    Phone:</td>
                <td  > 
                    <?php echo $this->_tpl_vars['account_info']['phone']; ?>
</td>
            </tr>		         
            <tr>
                <td  ><input type="checkbox" name="mobile" value="1" <?php if ($this->_tpl_vars['mobile']): ?> checked="checked"<?php endif; ?>/>
                    Mobile:</td>
                <td  > 
                    <?php echo $this->_tpl_vars['account_info']['mobile']; ?>
</td>
            </tr>				       
            <?php unset($this->_sections['balanceidx']);
$this->_sections['balanceidx']['name'] = 'balanceidx';
$this->_sections['balanceidx']['loop'] = is_array($_loop=$this->_tpl_vars['balances_list']) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['balanceidx']['show'] = true;
$this->_sections['balanceidx']['max'] = $this->_sections['balanceidx']['loop'];
$this->_sections['balanceidx']['step'] = 1;
$this->_sections['balanceidx']['start'] = $this->_sections['balanceidx']['step'] > 0 ? 0 : $this->_sections['balanceidx']['loop']-1;
if ($this->_sections['balanceidx']['show']) {
    $this->_sections['balanceidx']['total'] = $this->_sections['balanceidx']['loop'];
    if ($this->_sections['balanceidx']['total'] == 0)
        $this->_sections['balanceidx']['show'] = false;
} else
    $this->_sections['balanceidx']['total'] = 0;
if ($this->_sections['balanceidx']['show']):

            for ($this->_sections['balanceidx']['index'] = $this->_sections['balanceidx']['start'], $this->_sections['balanceidx']['iteration'] = 1;
                 $this->_sections['balanceidx']['iteration'] <= $this->_sections['balanceidx']['total'];
                 $this->_sections['balanceidx']['index'] += $this->_sections['balanceidx']['step'], $this->_sections['balanceidx']['iteration']++):
$this->_sections['balanceidx']['rownum'] = $this->_sections['balanceidx']['iteration'];
$this->_sections['balanceidx']['index_prev'] = $this->_sections['balanceidx']['index'] - $this->_sections['balanceidx']['step'];
$this->_sections['balanceidx']['index_next'] = $this->_sections['balanceidx']['index'] + $this->_sections['balanceidx']['step'];
$this->_sections['balanceidx']['first']      = ($this->_sections['balanceidx']['iteration'] == 1);
$this->_sections['balanceidx']['last']       = ($this->_sections['balanceidx']['iteration'] == $this->_sections['balanceidx']['total']);
?>	
            <tr>
                <td  ><input type="checkbox" name="balance_settings[]" value="<?php echo $this->_tpl_vars['balances_list'][$this->_sections['balanceidx']['index']]['balance_code']; ?>
"  />
                    Balance(<?php echo $this->_tpl_vars['balances_list'][$this->_sections['balanceidx']['index']]['balance_name']; ?>
):</td>
                <td  > 
                    <?php echo $this->_tpl_vars['balances_list'][$this->_sections['balanceidx']['index']]['balance_text']; ?>
</td>
            </tr>			
            <?php endfor; endif; ?>
            <tr>
                <td  ></td>
                <td  >  <input class="button" value="Apply Changes" type="submit" name="buttonUpdate"></td>
            </tr>	

        </table>
    </div>
</form>