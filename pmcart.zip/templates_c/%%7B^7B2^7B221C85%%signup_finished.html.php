<?php /* Smarty version 2.6.18, created on 2010-03-11 17:33:43
         compiled from home/signup_finished.html */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('function', 'dev_get_page_link', 'home/signup_finished.html', 18, false),)), $this); ?>
<div align="right">
  <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="650" id="AutoNumber1">
    <tr>
      <td width="100%">&nbsp;</td>
    </tr>
  </table>
</div>
<div align="center">
  <center>
  <table cellpadding="2" cellspacing="0" border="0" width="580" style="border-collapse: collapse" bordercolor="#111111" >
	<tr>
	  <td  class="pageHeading" height="50" valign="top"><b>
      <font face="Tahoma" color="#6666FF">Registration: Finished </font></b> </td>
	</tr>
	<tr><td><p><font size="2" face="Tahoma">Your registration is <font color="red"><strong>NOT</strong></font> yet complete! You <font color="red"><strong>MUST</strong></font> login to activate your account and complete your registration!<br />
An e-mail containing your new account number was sent to your e-mail address. Please check your spam folder if you cannot find our e-mail. You may try to open a new account with a different e-mail if you fail to receive our e-mail.<br /><br />

Please use your account number and the following login information to <a href="<?php echo smarty_function_dev_get_page_link(array('page' => 'PAGE_LOGIN'), $this);?>
">login</a> to your account and complete your registration.</font></p>
<font size="2" face="Tahoma"><br />
Listed below is your login information. Please print it or write it down: </font>
</td></tr>
</table>
      </center>
    </div>
    <div align="center">
      <center>
<table cellpadding="0" cellspacing="0" border="0" class="form_content" style="border-collapse: collapse" bordercolor="#111111">
	<tr>
	  <td class="form_label"><font size="2" face="Tahoma">Password:</font></td> <td class="form_field">
      <font size="2" face="Tahoma"><?php echo $this->_tpl_vars['secure_info']['password']; ?>
</font></td>
	  </tr>	
	<tr>
	  <td class="form_label"><font size="2" face="Tahoma">Login PIN:</font></td> <td class="form_field">
      <font size="2" face="Tahoma"><?php echo $this->_tpl_vars['secure_info']['login_pin']; ?>
</font></td>
	  </tr>	
	<tr>
	  <td class="form_label"><font size="2" face="Tahoma">Master Key:</font></td> <td class="form_field">
      <font size="2" face="Tahoma"><?php echo $this->_tpl_vars['secure_info']['master_key']; ?>
</font></td>
	  </tr>	
	<tr>
	  <td class="form_label"><font size="2" face="Tahoma">Security Question:</font></td> <td class="form_field">
      <font size="2" face="Tahoma"><?php echo $this->_tpl_vars['secure_info']['security_question']; ?>
</font></td>
	  </tr>	
	<tr>
	  <td class="form_label"><font size="2" face="Tahoma">Answer:</font></td> <td class="form_field">
      <font size="2" face="Tahoma"><?php echo $this->_tpl_vars['secure_info']['security_answer']; ?>
</font></td>
	  </tr>		  
</table>
	  
      </center>
    </div>
    <div align="center">
      <center>
      <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="580" id="AutoNumber2" height="30">
        <tr>
          <td width="100%">&nbsp;</td>
        </tr>
      </table>
      </center>
    </div>
    <div align="center">
      <center>
	  
<table cellpadding="2" cellspacing="0" border="0" width="580" style="border-collapse: collapse" bordercolor="#111111" >
<tr><td><font size="2" face="Tahoma">The above information will not be e-mailed to you for security reasons.<br />
For increased security we recommend not to store this information on your computer.<br />

Please <a href="<?php echo smarty_function_dev_get_page_link(array('page' => 'PAGE_LOGIN'), $this);?>
">login</a> to activate your account and complete the registration.
</font>
</td></tr>
</table></center>
      </div>