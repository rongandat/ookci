<?php /* Smarty version 2.6.18, created on 2012-05-23 19:45:54
         compiled from home/index.html */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('function', 'dev_get_page_link', 'home/index.html', 43, false),)), $this); ?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td valign="top" style="padding-left:20px;"><table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="450" id="AutoNumber51">
            <tr>
              <td width="100%">&nbsp;</td>
            </tr>
		     <tr>
                <td width="100%" height="25" valign="top">
                    <font face="Tahoma" size="2" color="#800000"><b>Move Your Money</b>
                    </font></td>
              </tr>
              <tr>
                <td width="100%">
                <blockquote>
                  <p><font face="Tahoma" size="2">Join the e-globalcash payment 
                  network and make fast and secure payments. Instant deposits, 
                  withdrawals, transfers to merchants and other e-globalcash members. </font>
                        </p>
                </blockquote>
                </td>
              </tr>
              <tr>
                <td width="100%">
                <blockquote>
                  <p><font face="Tahoma" size="2">Instant transfers to and from other digital currencies 
                        and banks via our network of trusted exchangers.</font></p>
                </blockquote>
                </td>
              </tr>
              <tr>
                <td width="100%" height="25" valign="top"><b>
                    <font face="Tahoma" size="2" color="#800000">Customer 
                    Service </font></b></td>
              </tr>
              <tr>
                <td width="100%">
                <blockquote>
                  <p>
                        <font face="Tahoma" size="2">Fast, efficient and 
                        friendly customer service is our promise to our valued 
                        members. So open an account right now. It&#39;s fast and 
                        free. <b><a href="<?php echo smarty_function_dev_get_page_link(array('page' => 'PAGE_SIGNUP','ssl' => true), $this);?>
">JOIN NOW</a></b> </font>
                        </p>
                </blockquote>
                </td>
              </tr>
              <tr>
                <td width="100%" height="25" valign="top">
                    <font face="Tahoma" size="2" color="#800000"><b>Update News</b>
                    </font>
                    <font face="Tahoma" size="2"><span style="font-weight: 400">
                    02.28.2010 </span>
                    </font></td>
              </tr>
              <tr>
                <td width="100%">
                <blockquote>
                  <p>
                      <font face="Tahoma" size="2">e-globalcash would like to welcome everyone to the 
                    future of electronic currency industry. In 2009 we have 
                    finally finished our expansion and transition to a state of 
                    the art, highly secure building, which allows our employees 
                    to provide even better service for you. We have worked very 
                    hard to complete this transition with no interruptions to 
                    our service. <b><a href="<?php echo smarty_function_dev_get_page_link(array('page' => 'PAGE_DEFAULT','ssl' => true), $this);?>
">for more detail and last 
                      archive news here.</a></b></font></p>
                </blockquote>
                </td>
              </tr>
            </table></td>
    <td rowspan="2" valign="top" style="padding-right:10px;"><table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%" id="AutoNumber42" height="222">
            <tr>
              <td width="100%" height="19">
              <div align="center">
                <center>
                <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="180" id="AutoNumber44">
                  <tr>
                    <td width="100%" background="http://www.e-globalcash.net/images/back.gif" height="220" valign="top">
                    <div align="center">
                      <center>
                      <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="150" id="AutoNumber45" height="163">
                        <tr>
                          <td width="100%" height="84">&nbsp;</td>
                        </tr>
                        <tr>
                          <td width="100%" height="19" valign="top">
                        <b>
                        <font face="Tahoma" size="2" color="#800000">Featured 
                        Merchant</font></b></td>
                        </tr>
                        <tr>
                          <td width="100%" height="42" valign="top">
                        <a href="http://invest-true.com/">
                        <font face="Tahoma" size="2">I</font></a><font face="Tahoma" size="2"><a href="http://invest-true.com/">nvest-true.com</a><img border="0" src="http://e-globalcash.net/images/new.gif" width="28" height="11"><br>
                        <a id="dlMerchant_ctl00_HyperLink11" href="http://www.instaforex.com" target="_blank">
                        InstaForex</a></font></td>
                        </tr>
                        <tr>
                          <td width="100%" height="10"><b>
                        <font face="Tahoma" size="2" color="#800000">Featured 
                        Exchanger</font></b></td>
                        </tr>
                        <tr>
                          <td width="100%" height="30" valign="top">
                        <font face="Tahoma" size="2">
                        <a id="dlExchanger_ctl00_HyperLink13" target="_blank" href="http://www.e-dollars.co/">
                        e-dollars.co</a><img border="0" src="http://e-globalcash.net/images/new.gif" width="28" height="11"><br>
                        <a id="dlExchanger_ctl00_HyperLink13" href="http://www.exkorea.net/" target="_blank">
                        exKorea.net</a><img border="0" src="http://e-globalcash.net/images/new.gif" width="28" height="11"><br>
                        <a id="dlExchanger_ctl00_HyperLink13" href="http://goldmediator.com/" target="_blank">
                        Goldmediator.com</a></font></td>
                        </tr>
                      </table>
                      </center>
                    </div>
                    </td>
                  </tr>
                </table>
                </center>
              </div>
              </td>
            </tr>
            <tr>
              <td width="100%" height="37">
              <p align="center"><font size="2" face="Tahoma">
                  <a href="http://www.e-globalcash.net/partners.htm">Your Business 
                  ads on the list</a></font></td>
            </tr>
            <tr>
              <td width="100%" height="147" valign="top">
              <p align="center"><font face="Tahoma"><a href="http://www.kitco.com/charts/popup/au24hr3day.html" target="_blank"><font size="2"><img src="http://www.kitco.com/images/live/t24_au_en_usoz_6.gif" width="180" height="114" alt="Click to enlarge" border="0"></font></a><font size="2"><br>
              </font><a href="http://www.kitco.com/charts/popup/au24hr3day.html" target="blank">
              <font size="2">Click for a 3 Days Graph</font></a></font></td>
            </tr>
            <tr>
              <td width="100%" height="19">&nbsp;</td>
            </tr>
          </table>
          <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%" id="AutoNumber43">
            <tr>
              <td width="100%">&nbsp;</td>
            </tr>
          </table>
          </td>
        </tr>
      </table></td>
  </tr>
  <tr>
    <td><table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="450" id="AutoNumber52">
              <tr>
                <td width="50%" valign="top">
                    <ul>
                      <li><font size="2" face="Tahoma"><b>Immediate payment</b> 
                      no waiting for checks to clear or credits to be made.</font></li>
                      <li><font face="Tahoma" size="2"><b>Low fees</b> lower 
                      than credit cards or competing payment services.</font></li>
                      <li><font face="Tahoma" size="2"><b>No chargebacks</b> 
                      &quot;Get paid, stay paid&quot; unlike credit card payments.</font></li>
                    </ul>
                    </td>
                <td width="50%" valign="top">
                    <ul>
                      <li><font face="Tahoma" size="2">Easy <b>Click To Pay</b> 
                      gateway allows anyone to accept e-globalcash on their web site 
                      (SCI, API guide coming soon!!).</font></li>
                      <li><font size="2" face="Tahoma">Secure, user friendly <b>
                      <a href="<?php echo smarty_function_dev_get_page_link(array('page' => 'PAGE_LOGIN','ssl' => true), $this);?>
">access to your account.</a></b></font></li>
                      <li><font size="2" face="Tahoma">Get and use e-globalcash at 
                      these <b><a href="<?php echo smarty_function_dev_get_page_link(array('page' => 'PAGE_EXCHANGERS','ssl' => true), $this);?>
">exchangers</a></b> and 
                      <b><a href="<?php echo smarty_function_dev_get_page_link(array('page' => 'PAGE_MERCHANTS','ssl' => true), $this);?>
">merchants.</a></b></font></li>
                    </ul>
                    </td>
              </tr>