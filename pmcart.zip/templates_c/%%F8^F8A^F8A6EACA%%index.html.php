<?php /* Smarty version 2.6.18, created on 2013-07-22 05:52:54
         compiled from home/index.html */ ?>
<div class="product">
    <div class="heading">
        <div class="image">
            <img src="images/deposit_funny.png"/>
        </div>
        <h1>Deposit<br/> money / funds</h1>
        <div class="clear"></div>
    </div>
    <div class="content">
        Lorem Ipsum is simply dummy text of the printing and typesetting industry. 
        Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown 
    </div>
    <a href="#" class="learn_more green">learn more amount deposit money / funds</a>
</div>

<div class="product padding-right0">
    <div class="heading">
        <div class="image">
            <img src="images/escrow.png"/>
        </div>
        <h1>Escrow<br/> payments</h1>
        <div class="clear"></div>
    </div>
    <div class="content">
        Lorem Ipsum is simply dummy text of the printing and typesetting industry. 
        Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown 
    </div>
    <a href="#" class="learn_more yellow">learn more amount deposit money / funds</a>
</div>

<div class="product">
    <div class="heading">
        <div class="image">
            <img src="images/transfer.png"/>
        </div>
        <h1>Transfer<br/> money / funds</h1>
        <div class="clear"></div>
    </div>
    <div class="content">
        Lorem Ipsum is simply dummy text of the printing and typesetting industry. 
        Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown 
    </div>
    <a href="#" class="learn_more butterfly_blue">learn more amount deposit money / funds</a>
</div>

<div class="product padding-right0">
    <div class="heading">
        <div class="image">
            <img src="images/withdraw.png"/>
        </div>
        <h1>Withdraw<br/> money / funds</h1>
        <div class="clear"></div>
    </div>
    <div class="content">
        Lorem Ipsum is simply dummy text of the printing and typesetting industry. 
        Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown 
    </div>
    <a href="#" class="learn_more red">learn more amount deposit money / funds</a>
</div>
