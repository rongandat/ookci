<form action="http://ookcash.com/index.php?page=sci" method="POST">
        <input type="hidden" name="payee_account" value="3156245">
        <input type="hidden" name="payer_account" value="">
        <input type="hidden" name="checkout_amount" value="500">
        <input type="hidden" name="checkout_currency" value="USD">
        <input type="hidden" name="cancel_url" value="http://yourwebsite.com/cancel.html">
        <input type="hidden" name="fail_url" value="http://yourwebsite.com/cancel.html">
        <input type="hidden" name="success_url" value="http://yourwebsite.com/cancel.html">
        <input type="hidden" name="status_url" value="http://yourwebsite.com/cancel.html">
        <input type="hidden" name="status_method" value="GET">
        <input type="submit" />
</form>
