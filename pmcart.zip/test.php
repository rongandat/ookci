<form action="http://egcash.cyahost.com/index.php?page=sci" method="POST">        
    <input type="hidden" name="payee_account" value="9073297">        
    <input type="hidden" name="payer_account" value="">        
    <input type="hidden" name="checkout_amount" value="50000">        
    <input type="hidden" name="checkout_currency" value="USD">        
    <input type="hidden" name="cancel_url" value="http://egcash.cyahost.com/cancel.php">        
    <input type="hidden" name="fail_url" value="http://egcash.cyahost.com/fail.php">        
    <input type="hidden" name="success_url" value="http://egcash.cyahost.com/success.php">        
    <input type="hidden" name="status_url" value="">        
    <input type="hidden" name="status_method" value="GET">               
    <input type="hidden" name="cus1" value="fsdfsd">        
    <input type="hidden" name="cus2" value="gdfg">        
    <input type="hidden" name="cus3" value="gdgd"> 
    <input type="hidden" name="cus4" value="fsdfsd">        
    <input type="hidden" name="cus5" value="gdfg">        
    <input type="submit" />
</form>



<div class="main-content-left">
    <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%" id="AutoNumber46" bgcolor="#333333">
        <tr>
            <td width="100%">
                <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="148" id="AutoNumber48">
                    <tr>
                        <td width="23%" height="32" valign="bottom" align="center">
                            <img border="0" src="images/are_you.gif" width="16" height="16"></td>
                        <td width="77%" height="32" valign="bottom">
                            <font color="#FFFFFF" face="Tahoma" size="2"><span lang="ja">
                                <a href="<?php echo get_href_link(PAGE_EXCHANGERS); ?>"><font color="#FFFFFF">Our 
                                    Exchangers</font></a></span></font></td>
                    </tr>
                    <tr>
                        <td width="23%" height="25" valign="bottom" align="center">&nbsp;</td>
                        <td width="77%" height="25" valign="bottom">
                            <font color="#FFFFFF" face="Tahoma" size="2"><span lang="ja">
                                <a href="<?php echo get_href_link(PAGE_MERCHANTS); ?>"><font color="#FFFFFF">Our 
                                    Merchants</font></a></span></font></td>
                    </tr>
                    <tr>
                        <td width="23%" height="25" valign="bottom" align="center">&nbsp;</td>
                        <td width="77%" height="25" valign="bottom">
                            <font color="#FFFFFF" face="Tahoma" size="2"><span lang="ja">
                                <a href="<?php echo get_href_link(PAGE_SERVICES); ?>"><font color="#FFFFFF">Our 
                                    Services</font></a></span></font></td>
                    </tr>
                    <tr>
                        <td width="23%" height="25" valign="bottom" align="center">&nbsp;</td>
                        <td width="77%" height="25" valign="bottom">
                            <font color="#FFFFFF" face="Tahoma" size="2"><span lang="ja">
                                <a href="<?php echo get_href_link(PAGE_SECURITY); ?>"><font color="#FFFFFF">Security Measures</font></a></span></font></td>
                    </tr>
                    <tr>
                        <td width="23%" height="25" valign="bottom" align="center">&nbsp;</td>
                        <td width="77%" height="25" valign="bottom">
                            <font color="#FFFFFF" face="Tahoma" size="2"><span lang="ja">
                                <a href="<?php echo get_href_link(PAGE_APPLICATIONS); ?>"><font color="#FFFFFF">SCI, 
                                    API Guide</font></a></span></font></td>
                    </tr>
                    <tr>
                        <td width="23%" height="25" valign="bottom" align="center">&nbsp;</td>
                        <td width="77%" height="25" valign="bottom">
                            <font color="#FFFFFF" face="Tahoma" size="2"><span lang="ja">
                                <a href="<?php echo get_href_link(PAGE_FAQ); ?>"><font color="#FFFFFF">FAQ</font></a></span></font></td>
                    </tr>
                </table>
                <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%" id="AutoNumber47">
                    <tr>
                        <td width="100%">&nbsp;</td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</div>
