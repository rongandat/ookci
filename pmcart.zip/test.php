<form action="http://egcash.cyahost.com/index.php?page=sci" method="POST">        
    <input type="hidden" name="payee_account" value="9073297">        
    <input type="hidden" name="payer_account" value="">        
    <input type="hidden" name="checkout_amount" value="50000">        
    <input type="hidden" name="checkout_currency" value="USD">        
    <input type="hidden" name="cancel_url" value="http://egcash.cyahost.com/cancel.php">        
    <input type="hidden" name="fail_url" value="http://egcash.cyahost.com/fail.php">        
    <input type="hidden" name="success_url" value="http://egcash.cyahost.com/success.php">        
    <input type="hidden" name="status_url" value="">        
    <input type="hidden" name="status_method" value="GET">               
    <input type="hidden" name="cus1" value="fsdfsd">        
    <input type="hidden" name="cus2" value="gdfg">        
    <input type="hidden" name="cus3" value="gdgd"> 
    <input type="hidden" name="cus4" value="fsdfsd">        
    <input type="hidden" name="cus5" value="gdfg">        
    <input type="submit" />
</form>