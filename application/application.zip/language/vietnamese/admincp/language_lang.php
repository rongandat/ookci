<?php

$lang['heading_title'] = 'Ngôn Ngữ';
$lang['btn_add_language'] = 'Thêm Ngôn Ngữ';

$lang['text_name'] = 'Name';
$lang['text_code'] = 'Code';
$lang['text_locale'] = 'locale';
$lang['text_directory'] = 'Directory';
$lang['text_status'] = 'Trạng thái';
$lang['text_action'] = 'Action';


$lang['entry_name'] = 'Name';
$lang['entry_code'] = 'Code';
$lang['entry_locale'] = 'Locale';
$lang['entry_image'] = 'Image';
$lang['entry_directory'] = 'Directory';
$lang['entry_filename'] = 'Filename';
$lang['entry_sort_order'] = 'Sort Order';
$lang['entry_status'] = 'Status';