<?php /* Smarty version Smarty-3.1.14, created on 2013-08-16 11:57:54
         compiled from "application\views\templates\sci\zend_form.html" */ ?>
<?php /*%%SmartyHeaderCode:3431520c5dd8a6dad6-91275484%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '050ca1e429baf4c2410eb60ca2b873d8ff627265' => 
    array (
      0 => 'application\\views\\templates\\sci\\zend_form.html',
      1 => 1376625554,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '3431520c5dd8a6dad6-91275484',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.14',
  'unifunc' => 'content_520c5dd8b54289_27480961',
  'variables' => 
  array (
    'post_link' => 0,
    'posts_value' => 0,
    'k' => 0,
    'foo' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_520c5dd8b54289_27480961')) {function content_520c5dd8b54289_27480961($_smarty_tpl) {?><form action="<?php echo $_smarty_tpl->tpl_vars['post_link']->value;?>
" method="POST">
    <?php  $_smarty_tpl->tpl_vars['foo'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['foo']->_loop = false;
 $_smarty_tpl->tpl_vars['k'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['posts_value']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['foo']->key => $_smarty_tpl->tpl_vars['foo']->value){
$_smarty_tpl->tpl_vars['foo']->_loop = true;
 $_smarty_tpl->tpl_vars['k']->value = $_smarty_tpl->tpl_vars['foo']->key;
?>
    <input type="hidden" name="<?php echo $_smarty_tpl->tpl_vars['k']->value;?>
" value="<?php echo $_smarty_tpl->tpl_vars['foo']->value;?>
">
    <?php } ?>
    <input type="submit" />
</form>
<?php }} ?>