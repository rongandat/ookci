<?php /* Smarty version Smarty-3.1.14, created on 2013-08-20 04:38:04
         compiled from "application\views\templates\register\personal.html" */ ?>
<?php /*%%SmartyHeaderCode:95765212d65adb6a99-43777824%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'ce0a2e2478489ea3605a374ee4ba6a911ca53cd4' => 
    array (
      0 => 'application\\views\\templates\\register\\personal.html',
      1 => 1376966283,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '95765212d65adb6a99-43777824',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.14',
  'unifunc' => 'content_5212d65b04b1f0_56485915',
  'variables' => 
  array (
    'posts' => 0,
    'countries_array' => 0,
    'country_id' => 0,
    'months_array' => 0,
    'dobMonth' => 0,
    'days_array' => 0,
    'dobDay' => 0,
    'years_array' => 0,
    'dobYear' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5212d65b04b1f0_56485915')) {function content_5212d65b04b1f0_56485915($_smarty_tpl) {?><?php if (!is_callable('smarty_function_html_options')) include 'F:\\ookcash\\system\\Smarty\\libs\\plugins\\function.html_options.php';
?><form name="frmSignup" method="post" action=""  >
    <input type="hidden" name="action" value="process"  />
    <div class="simple-form">
        <h1>Registration: Part 2 of 2</h1>
        <p>Your account is not yet active. Please complete this form to activate your account.</p>
        <p>Fields marked with asterisk (<i>*</i>) are required.</p>
        <div class="line"></div>
        <div class="clear"></div>
        <?php echo $_smarty_tpl->getSubTemplate ("common/validate_error.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

        <h3>Personal Information</h3>
        <table class="form">

            <tr>
                <td class="form_label"><i>*</i>Account Name:</td>
                <td class="form_field">
                    <input  name="account_name" type="text"  value="<?php if (!empty($_smarty_tpl->tpl_vars['posts']->value['account_name'])){?><?php echo $_smarty_tpl->tpl_vars['posts']->value['account_name'];?>
<?php }?>"  class="inputtext" size="20"  /></td>
            </tr>	
            <tr>
                <td class="form_label">Company Name:</td>
                <td class="form_field">
                    <input  name="company_name" type="text"  value="<?php if (!empty($_smarty_tpl->tpl_vars['posts']->value['company_name'])){?><?php echo $_smarty_tpl->tpl_vars['posts']->value['company_name'];?>
<?php }?>"  class="inputtext" size="20"  /></td>
            </tr>		  
            <tr>
                <td class="form_label"><i>*</i>Address:</td>
                <td class="form_field">
                    <input  name="address" type="text"  value="<?php if (!empty($_smarty_tpl->tpl_vars['posts']->value['address'])){?><?php echo $_smarty_tpl->tpl_vars['posts']->value['address'];?>
<?php }?>"  class="inputtext" size="20"  /></td>
            </tr>	

            <tr> <td class="form_label">
                    <i>*</i>Country:</td>	  
                <td class="form_field"><select name="country_id"  class="inputselect"  onchange="getStates(this.value);">
                        <?php echo smarty_function_html_options(array('options'=>$_smarty_tpl->tpl_vars['countries_array']->value,'selected'=>$_smarty_tpl->tpl_vars['country_id']->value),$_smarty_tpl);?>
</select>

                </td></tr>	
            <tr>
                <td class="form_label"><i>*</i>City:</td>
                <td class="form_field">
                    <input  name="city" type="text"  value="<?php if (!empty($_smarty_tpl->tpl_vars['posts']->value['city'])){?><?php echo $_smarty_tpl->tpl_vars['posts']->value['city'];?>
<?php }?>"  class="inputtext" size="20"  /></td>
            </tr>	

            <tr>
                <td class="form_label"><i>*</i>Zip/Post Code:</td>
                <td class="form_field">
                    <input  name="postcode" type="text"  value="<?php if (!empty($_smarty_tpl->tpl_vars['posts']->value['postcode'])){?><?php echo $_smarty_tpl->tpl_vars['posts']->value['postcode'];?>
<?php }?>"  class="inputtext" size="20"  /></td>
            </tr>		  
            <tr>
                <td class="form_label"><i>*</i>Date of Birth:</td>
                <td  class="form_field"><select name="dobMonth" class="inputselect">
                        <?php echo smarty_function_html_options(array('options'=>$_smarty_tpl->tpl_vars['months_array']->value,'selected'=>$_smarty_tpl->tpl_vars['dobMonth']->value),$_smarty_tpl);?>
</select>&nbsp;<select name="dobDay" class="inputselect">
                        <?php echo smarty_function_html_options(array('options'=>$_smarty_tpl->tpl_vars['days_array']->value,'selected'=>$_smarty_tpl->tpl_vars['dobDay']->value),$_smarty_tpl);?>
</select>&nbsp;&nbsp;

                    <select name="dobYear" class="inputselect">
                        <?php echo smarty_function_html_options(array('options'=>$_smarty_tpl->tpl_vars['years_array']->value,'selected'=>$_smarty_tpl->tpl_vars['dobYear']->value),$_smarty_tpl);?>
</select>&nbsp;(mm/dd/yy)

                </td></tr>	 	  		
            <tr>
                <td class="form_label"><i>*</i>Phone:</td>
                <td class="form_field">
                    <input  name="phone" type="text"  value="<?php if (!empty($_smarty_tpl->tpl_vars['posts']->value['phone'])){?><?php echo $_smarty_tpl->tpl_vars['posts']->value['phone'];?>
<?php }?>"  class="inputtext" size="20"  /></td>
            </tr>		  
            <tr>
                <td class="form_label">Mobile:</td>
                <td class="form_field">
                    <input  name="mobile" type="text"  value="<?php if (!empty($_smarty_tpl->tpl_vars['posts']->value['mobile'])){?><?php echo $_smarty_tpl->tpl_vars['posts']->value['mobile'];?>
<?php }?>"  class="inputtext" size="20"  /></td>
            </tr>		  
            <tr >
                <td></td>
                <td ><input  type="submit" name="buttonSubmit" class="button"  value="Submit" />&nbsp;
                    <input  type="button" name="buttonCancel" onclick="window.location='<?php echo site_url('home');?>
';"  class="button"  value="Cancel"></td>
            </tr>
        </table>
    </div>
<?php }} ?>