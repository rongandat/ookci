<?php /* Smarty version Smarty-3.1.14, created on 2013-08-20 05:01:56
         compiled from "application\views\templates\register\index.html" */ ?>
<?php /*%%SmartyHeaderCode:2830952118e7f5987f1-61101738%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '0175fc5df45de604c4aacb638c31088076b7aa54' => 
    array (
      0 => 'application\\views\\templates\\register\\index.html',
      1 => 1376967715,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2830952118e7f5987f1-61101738',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.14',
  'unifunc' => 'content_52118e7f730b80_43376633',
  'variables' => 
  array (
    'posts' => 0,
    'security_questions_array' => 0,
    'security_question' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_52118e7f730b80_43376633')) {function content_52118e7f730b80_43376633($_smarty_tpl) {?><?php if (!is_callable('smarty_function_html_options')) include 'F:\\ookcash\\system\\Smarty\\libs\\plugins\\function.html_options.php';
?><form name="frmSignup" method="post" action=""  >
    <input type="hidden" name="action" value="process"  />
    <div class="simple-form">
        <h1>Registration: Part 1 of 2</h1>
        <p>Thank you for deciding to open a 
            OOKCASH account. Please follow directions carefully to avoid mistakes and delays during the registration process.</p>
        <p>Fields marked with asterisk (<i>*</i>) are required.</p>
        <div class="line"></div>
        <div class="clear"></div>
        <?php echo $_smarty_tpl->getSubTemplate ("common/validate_error.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

        <table class="form">

            <tr>
                <td class="form_label"><i>*</i>First Name:</td>
                <td class="form_field">
                    <input  name="firstname" type="text"  value="<?php if (!empty($_smarty_tpl->tpl_vars['posts']->value['firstname'])){?><?php echo $_smarty_tpl->tpl_vars['posts']->value['firstname'];?>
<?php }?>"  class="inputtext" size="20"  /></td>
            </tr>	
            <tr>
                <td class="form_label"><i>*</i>Last Name:</td>
                <td class="form_field">
                    <input  name="lastname" type="text"  value="<?php if (!empty($_smarty_tpl->tpl_vars['posts']->value['lastname'])){?><?php echo $_smarty_tpl->tpl_vars['posts']->value['lastname'];?>
<?php }?>"  class="inputtext" size="20"  /></td>
            </tr>		  
            <tr>
                <td class="form_label"><i>*</i>E-mail:</td>
                <td  class="form_field">
                    <input  name="email" type="text" id="email"  value="<?php if (!empty($_smarty_tpl->tpl_vars['posts']->value['email'])){?><?php echo $_smarty_tpl->tpl_vars['posts']->value['email'];?>
<?php }?>"   class="inputtext" size="20" />
                </td>
            </tr>	  
            <tr>
                <td class="form_label"><i>*</i>Re-enter e-mail:</td>
                <td  class="form_field">
                    <input  name="confirm_email" type="text" id="confirm_email"  value="<?php if (!empty($_smarty_tpl->tpl_vars['posts']->value['confirm_email'])){?><?php echo $_smarty_tpl->tpl_vars['posts']->value['confirm_email'];?>
<?php }?>"   class="inputtext" size="20" />
                </td>
            </tr>	  

        </table>	
        <h3>Security Information </h3>
        <p>Password, login PIN and master key will be automatically generated for your account</p>
        <table class="form">
            <tr>
                <td class="form_label"><i>*</i>Security Question:</td>
                <?php if (!empty($_smarty_tpl->tpl_vars['posts']->value['security_question'])){?>
                <?php $_smarty_tpl->tpl_vars["security_question"] = new Smarty_variable($_smarty_tpl->tpl_vars['posts']->value['security_question'], true, 0);?>
                <?php }else{ ?>
                <?php $_smarty_tpl->tpl_vars["security_question"] = new Smarty_variable(0, true, 0);?>
                <?php }?>
                <td class="form_field"><select name="security_question" class="inputselect" onchange="checkSecurityQuestion(this.value);">
                        <?php echo smarty_function_html_options(array('options'=>$_smarty_tpl->tpl_vars['security_questions_array']->value,'selected'=>$_smarty_tpl->tpl_vars['security_question']->value),$_smarty_tpl);?>
</select></td>
            </tr>	
            <tr id="content_custom_question" <?php if ($_smarty_tpl->tpl_vars['security_question']->value!=-1){?> style="display: none;" <?php }?>>
                <td class="form_label"><i>*</i>or write your own:</td>
                <td class="form_field">
                    <input  name="custom_question" type="text"  value="<?php if (!empty($_smarty_tpl->tpl_vars['posts']->value['firstname'])){?><?php echo $_smarty_tpl->tpl_vars['posts']->value['firstname'];?>
<?php }?>"  class="inputtext" size="20"  /></td> 
            </tr>	
            <tr>
                <td class="form_label"><i>*</i>Answer:</td>
                <td class="form_field">
                    <input  name="security_answer" type="text"  value="<?php if (!empty($_smarty_tpl->tpl_vars['posts']->value['security_answer'])){?><?php echo $_smarty_tpl->tpl_vars['posts']->value['security_answer'];?>
<?php }?>"  class="inputtext" size="20"  /></td> </tr>		  
            <tr>
                <td class="form_label"><i>*</i>Personal welcome message:</td>
                <td class="form_field">
                    <textarea  name="welcome_message" rows="3" cols="50" class="inputtextarea"><?php if (!empty($_smarty_tpl->tpl_vars['posts']->value['security_answer'])){?><?php echo $_smarty_tpl->tpl_vars['posts']->value['security_answer'];?>
<?php }?></textarea>
                </td>
            </tr>
            <tr>
                <td >
                    <strong>Enter the code (turing number) shown on the image</strong>	
                    <br />Cannot read the numbers? Click on it to get a new one
                </td>
                <td>
                    <a href="javascript: refreshSecureImage();"><img src="<?php echo site_url('secure_image');?>
"   border="0" id="secure_image" /></a><br />
                    <input   name="security_code"   class="inputtext" size="20"/>
                    <a  href="<?php echo site_url('contact_us');?>
" class="link">Cannot see Turing number at all?</a>

                </td>
            </tr>
            <tr>
                <td></td>
                <td>
                    If you agree with <a href="http://docs.ookcash.com/tos/" target="_blank">Terms of Our Service</a> click "Agree" to continue the registration.
                </td>

            </tr>
            <tr>
                <td >

                </td>
                <td>
                    <div class="buttons">
                        <input  type="submit" name="buttonAgree" class="button"  value="Agree" />
                        <input  type="button" name="buttonDisagree" onclick="window.location='<?php echo site_url('home');?>
';"  class="button"  value="Disagree">
                    </div>
                </td>
            </tr>
        </table>

    </div>

</form>


<script type="text/javascript">
    
    function checkSecurityQuestion(security_question_id) {
        if (security_question_id==-1) {
            $("#content_custom_question").show();
        } else {
            $("#content_custom_question").hide();	
        }
    }
    
</script><?php }} ?>