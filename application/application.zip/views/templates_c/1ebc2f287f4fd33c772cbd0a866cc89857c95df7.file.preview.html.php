<?php /* Smarty version Smarty-3.1.14, created on 2013-08-16 11:34:54
         compiled from "application\views\templates\sci\preview.html" */ ?>
<?php /*%%SmartyHeaderCode:5378520d91e4f0bfd7-96310729%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '1ebc2f287f4fd33c772cbd0a866cc89857c95df7' => 
    array (
      0 => 'application\\views\\templates\\sci\\preview.html',
      1 => 1376645692,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '5378520d91e4f0bfd7-96310729',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.14',
  'unifunc' => 'content_520d91e5080696_45976322',
  'variables' => 
  array (
    'user_session' => 0,
    'sci_user' => 0,
    'sci_info' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_520d91e5080696_45976322')) {function content_520d91e5080696_45976322($_smarty_tpl) {?><?php if (!is_callable('smarty_modifier_base64_decode')) include 'F:\\ookcash\\system\\Smarty\\libs\\plugins\\modifier.base64_decode.php';
?><div class="simple-form">
    <h1>Transfer Confirmation</h1>
    <form name="frmTransfer" method="post" action="<?php echo site_url('sci/complete');?>
" >
        <div class="line"></div>
        <?php echo $_smarty_tpl->getSubTemplate ("common/validate_error.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

        <table class="form">
            <tr>
                <td class="form_label">From Account:</td>
                <td class="form_field"><?php echo $_smarty_tpl->tpl_vars['user_session']->value['account_number'];?>
(<strong><?php echo $_smarty_tpl->tpl_vars['user_session']->value['account_name'];?>
</strong>)</td>
            </tr>	
            <tr>
                <td class="form_label">To Account:</td>
                <td class="form_field"><?php echo $_smarty_tpl->tpl_vars['sci_user']->value['account_number'];?>
(<strong><?php echo $_smarty_tpl->tpl_vars['sci_user']->value['account_name'];?>
</strong>)</td>
            </tr>	
            <tr>
                <td class="form_label">Amount:</td>
                <td class="form_field"><?php echo $_smarty_tpl->tpl_vars['sci_info']->value['balance'];?>
</td>

            </tr>	
            <tr>
                <td class="form_label">Fee:</td>
                <td class="form_field"><?php echo $_smarty_tpl->tpl_vars['sci_info']->value['fees_text'];?>
</td>
            </tr>  
            <?php if ($_smarty_tpl->tpl_vars['sci_info']->value['transaction_memo']!=''){?>

            <tr>
                <td class="form_label">Transaction Memo:</td>
                <td class="form_field"><?php echo $_smarty_tpl->tpl_vars['sci_info']->value['transaction_memo'];?>
</td>
            </tr>  
            <?php }?>   
        </table>	  

        <p>Please be aware that all OOKCASH payments are instant and irreversible. OOKCASH is not associated directly or indirectly with any other company or business. Our liability is limited to delivering your funds on time to the account of your choice specified above. Any issues that you may encounter as a result of this transaction that are not related to the transaction itself will have to be addressed and resolved with the recipient of your payment directly. Please confirm your payment details ONLY if you UNDERSTAND and AGREE with statements made in this paragraph and ACCEPT our <a href="http://docs.ookcash.com/tos/" target="_blank">Terms Of Service</a></p>
        <div class="buttons">
            <input  type="submit" name="buttonConfirm" class="button"  value="Confirm" />.
            <?php if (!empty($_smarty_tpl->tpl_vars['sci_info']->value['cancel_url'])){?>
            <input  type="button" name="buttonCancel" class="button"  value="Cancel" onclick="redirect('<?php echo smarty_modifier_base64_decode($_smarty_tpl->tpl_vars['sci_info']->value['cancel_url']);?>
');" />
            <?php }?>
        </div>
    </form>
</div><?php }} ?>