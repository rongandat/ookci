<?php /* Smarty version Smarty-3.1.14, created on 2013-08-16 06:31:37
         compiled from "application\views\templates\common\bottom.html" */ ?>
<?php /*%%SmartyHeaderCode:15009520c5674bb8020-85498724%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'c389aa8142aec8aac5bd138466d81d1a587913c4' => 
    array (
      0 => 'application\\views\\templates\\common\\bottom.html',
      1 => 1376625554,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '15009520c5674bb8020-85498724',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.14',
  'unifunc' => 'content_520c5674bdc060_07769264',
  'variables' => 
  array (
    'class' => 0,
    'action' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_520c5674bdc060_07769264')) {function content_520c5674bdc060_07769264($_smarty_tpl) {?><?php if ($_smarty_tpl->tpl_vars['class']->value=='home'&&$_smarty_tpl->tpl_vars['action']->value=='index'){?>
<div class="clear"></div>
<div class="accept">
    <h1>We Accept</h1>
    <div class="content">
        <img src="<?php echo base_url('public_html/images/visa.png');?>
"/>
    </div>
</div>
<div class="clear"></div>
<?php }?><?php }} ?>