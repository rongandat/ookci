<?php /* Smarty version Smarty-3.1.14, created on 2013-08-16 11:56:08
         compiled from "application\views\templates\sci\generate.html" */ ?>
<?php /*%%SmartyHeaderCode:284520c562575a066-94890532%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'ea442bbdfc5ace1351bbfa8ea954872403ed8641' => 
    array (
      0 => 'application\\views\\templates\\sci\\generate.html',
      1 => 1376625554,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '284520c562575a066-94890532',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.14',
  'unifunc' => 'content_520c56258fa402_75938049',
  'variables' => 
  array (
    'posts' => 0,
    'balance_currencies' => 0,
    'balance_currency' => 0,
    'fields_extra' => 0,
    'zend_code_link' => 0,
    'zend_code_html' => 0,
    'zend_code_buton' => 0,
    'zend_code_form' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_520c56258fa402_75938049')) {function content_520c56258fa402_75938049($_smarty_tpl) {?><?php if (!is_callable('smarty_function_html_options')) include 'F:\\ookcash\\system\\Smarty\\libs\\plugins\\function.html_options.php';
?><div class="simple-form">
    <h1>Global Checkout Button/Form Generator</h1>
    <div class="line"></div>
     <?php echo $_smarty_tpl->getSubTemplate ("common/validate_error.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

    <form action="" method="post">
        <h3>Checkout Information</h3>
        <div class="st-form-line">
            <span class="st-labeltext"><i>*</i> Your Account Number </span>
            <div class="block">
                <input type="text" class="st-forminput hurge" name="payee_account" value="<?php if (!empty($_smarty_tpl->tpl_vars['posts']->value['payee_account'])){?><?php echo $_smarty_tpl->tpl_vars['posts']->value['payee_account'];?>
<?php }?>" >
                <span class="information">(please input your account number that you want customer pay to. The field is required. Examples: 6868688)</span>
            </div>
            <div class="clear"></div>
        </div>
        <div class="st-form-line">
            <span class="st-labeltext">Payer Account Number </span>
            <div class="block">
                <input type="text" class="st-forminput hurge" name="payer_account" value="<?php if (!empty($_smarty_tpl->tpl_vars['posts']->value['payer_account'])){?><?php echo $_smarty_tpl->tpl_vars['posts']->value['payer_account'];?>
<?php }?>" >
                <span class="information">please input account number of who you want to receive money from. The field is not required, leave it empty if you want anyone can send you money.<br/> Example: 988888 </span>
            </div>
            <div class="clear"></div>
        </div>
        <div class="st-form-line">
            <span class="st-labeltext"> Amount</span>
            <div class="block">
                <input type="text" class="st-forminput hurge" name="checkout_amount" value="<?php if (!empty($_smarty_tpl->tpl_vars['posts']->value['checkout_amount'])){?><?php echo $_smarty_tpl->tpl_vars['posts']->value['checkout_amount'];?>
<?php }?>" >

                <span class="information"> Amount is not required field, leave it empty if you want Payer pay any amount like donation. Example: 5,3.99 </span>
            </div>
            <div class="clear"></div>
        </div>
        <div class="st-form-line">
            <span class="st-labeltext"> Currency</span>
            <div class="block">
                <?php if (!empty($_smarty_tpl->tpl_vars['posts']->value['checkout_currency'])){?>
                <?php $_smarty_tpl->tpl_vars["balance_currency"] = new Smarty_variable($_smarty_tpl->tpl_vars['posts']->value['checkout_currency'], null, 0);?>
                <?php }else{ ?>
                <?php $_smarty_tpl->tpl_vars["balance_currency"] = new Smarty_variable(0, null, 0);?>
                <?php }?>
                <select id="" class="form" name="checkout_currency">
                    <?php echo smarty_function_html_options(array('options'=>$_smarty_tpl->tpl_vars['balance_currencies']->value,'selected'=>$_smarty_tpl->tpl_vars['balance_currency']->value),$_smarty_tpl);?>

                </select>
            </div>
            <div class="clear"></div>
        </div>
        <div class="st-form-line">
            <span class="st-labeltext">Cancel URL</span>
            <div class="block">
                <input type="text" class="st-forminput bighurge" name="cancel_url" value="<?php if (!empty($_smarty_tpl->tpl_vars['posts']->value['cancel_url'])){?><?php echo $_smarty_tpl->tpl_vars['posts']->value['cancel_url'];?>
<?php }?>" >
                <span class="information"> The field is not required but if you input the value, when your customer cancel their order, our serivce will help you to redirect them back to your site. Example: http://yourwebsite.com/cancel.html?param1=value1¶m2=value2 </span>
            </div>
            <div class="clear"></div>
        </div>
        <div class="st-form-line">
            <span class="st-labeltext">Fail URL</span>
            <div class="block">
                <input type="text" class="st-forminput bighurge" name="fail_url" value="<?php if (!empty($_smarty_tpl->tpl_vars['posts']->value['fail_url'])){?><?php echo $_smarty_tpl->tpl_vars['posts']->value['fail_url'];?>
<?php }?>" >
                <span class="information">  The field is not required but if you input a value, Payer will be redirect to Fail URL if any problem during progress on our service </span>
            </div>
            <div class="clear"></div>
        </div>
        <div class="st-form-line">
            <span class="st-labeltext"> Success URL:</span>
            <div class="block">
                <input type="text" class="st-forminput bighurge" name="success_url" value="<?php if (!empty($_smarty_tpl->tpl_vars['posts']->value['success_url'])){?><?php echo $_smarty_tpl->tpl_vars['posts']->value['success_url'];?>
<?php }?>" >
                <span class="information"> The field is not required but if the value is inputed, Payer will be redirect to the Success URL after he/she made payment </span>
            </div>
            <div class="clear"></div>
        </div>
        <div class="st-form-line">
            <span class="st-labeltext"> Status URL:</span>
            <div class="block">
                <input type="text" class="st-forminput bighurge" name="status_url" value="<?php if (!empty($_smarty_tpl->tpl_vars['posts']->value['status_url'])){?><?php echo $_smarty_tpl->tpl_vars['posts']->value['status_url'];?>
<?php }?>" >
                <span class="information">  The field is not required but it is very useful one. If you input the value, all of important transaction verification data will be reponse back to the URL to help you verify your order status on our service. This also help you to protect any frauds, hacking during business. </span>
            </div>
            <div class="clear"></div>
        </div>
        <div class="st-form-line">
            <span class="st-labeltext"> Status Method:</span>
            <div class="block">
                <select name="status_method">
                    <option <?php if (!empty($_smarty_tpl->tpl_vars['posts']->value['status_method'])&&$_smarty_tpl->tpl_vars['posts']->value['status_method']=='GET'){?>SELECTED<?php }?> value="GET">GET</option>
                    <option <?php if (!empty($_smarty_tpl->tpl_vars['posts']->value['status_method'])&&$_smarty_tpl->tpl_vars['posts']->value['status_method']=='POST'){?>SELECTED<?php }?> value="POST">POST</option>
                </select>
                <span class="information">The field used to define the postback method that our service will use to POST/GET response data to your Status URL </span>
            </div>
            <div class="clear"></div>
        </div>
        <div class="line"></div>
        <h3> Extra Fields</h3>
        <?php if (isset($_smarty_tpl->tpl_vars['smarty']->value['section']['foo'])) unset($_smarty_tpl->tpl_vars['smarty']->value['section']['foo']);
$_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['name'] = 'foo';
$_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['start'] = (int)0;
$_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['loop'] = is_array($_loop=$_smarty_tpl->tpl_vars['fields_extra']->value) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['step'] = ((int)1) == 0 ? 1 : (int)1;
$_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['show'] = true;
$_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['max'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['loop'];
if ($_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['start'] < 0)
    $_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['start'] = max($_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['step'] > 0 ? 0 : -1, $_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['loop'] + $_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['start']);
else
    $_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['start'] = min($_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['start'], $_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['step'] > 0 ? $_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['loop'] : $_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['loop']-1);
if ($_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['show']) {
    $_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['total'] = min(ceil(($_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['step'] > 0 ? $_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['loop'] - $_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['start'] : $_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['start']+1)/abs($_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['step'])), $_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['max']);
    if ($_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['total'] == 0)
        $_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['show'] = false;
} else
    $_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['total'] = 0;
if ($_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['show']):

            for ($_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['index'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['start'], $_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['iteration'] = 1;
                 $_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['iteration'] <= $_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['total'];
                 $_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['index'] += $_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['step'], $_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['iteration']++):
$_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['rownum'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['iteration'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['index_prev'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['index'] - $_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['step'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['index_next'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['index'] + $_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['step'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['first']      = ($_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['iteration'] == 1);
$_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['last']       = ($_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['iteration'] == $_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['total']);
?>
        <table class="form">
            <tr>
                <td style=" width: 225px;"><input style="display: block;" type="text" name="extra_field[<?php echo $_smarty_tpl->getVariable('smarty')->value['section']['foo']['index'];?>
]" value="<?php if (!empty($_smarty_tpl->tpl_vars['posts']->value['extra_field'][$_smarty_tpl->getVariable('smarty',null,true,false)->value['section']['foo']['index']])){?><?php echo $_smarty_tpl->tpl_vars['posts']->value['extra_field'][$_smarty_tpl->getVariable('smarty')->value['section']['foo']['index']];?>
<?php }?>" class="st-forminput large"></td>
                <td>=</td>
                <td style=" width: 225px;"><input style="display: block;float: right" type="text" name="extra_value[<?php echo $_smarty_tpl->getVariable('smarty')->value['section']['foo']['index'];?>
]" value="<?php ob_start();?><?php echo $_smarty_tpl->getVariable('smarty')->value['section']['foo']['index'];?>
<?php $_tmp1=ob_get_clean();?><?php if (!empty($_smarty_tpl->tpl_vars['posts']->value['extra_value'][$_tmp1])){?><?php ob_start();?><?php echo $_smarty_tpl->getVariable('smarty')->value['section']['foo']['index'];?>
<?php $_tmp2=ob_get_clean();?><?php echo $_smarty_tpl->tpl_vars['posts']->value['extra_value'][$_tmp2];?>
<?php }?>" class="st-forminput large"></td>
            </tr>
        </table>
        <?php endfor; endif; ?>
        <div class="st-form-line">
            <span class="st-labeltext"></span>
            <input type="submit" value="Submit" class="button">
            <div class="clear"></div>
        </div>

    </form>
    <div class="line"></div>
    <?php if (!empty($_smarty_tpl->tpl_vars['zend_code_link']->value)){?>
    <table border="0" bgcolor="#CCCCCC" style="padding: 20px 50px;" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%" id="AutoNumber39">
        <tr>
            <td width="100%" height="30" valign="top"><b>
                    <font size="2" face="Tahoma" color="#800000"> SCI Link:</font></b></td>
        </tr>

        <tr>
            <td>
                <textarea readonly="readonly" rows="8" cols="80"><?php echo $_smarty_tpl->tpl_vars['zend_code_link']->value;?>
</textarea>
            </td>
        </tr>
    </table>

    <?php }?>
    <?php if (!empty($_smarty_tpl->tpl_vars['zend_code_html']->value)){?>

    <table border="0" bgcolor="#CCCCCC" style="padding: 20px 50px;" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%" id="AutoNumber39">
        <tr>
            <td width="100%" height="30" valign="top"><b>
                    <font size="2" face="Tahoma" color="#800000"> SCI HTML:</font></b></td>
        </tr>

        <tr>
            <td>
                <textarea readonly="readonly" rows="8" cols="80"><?php echo $_smarty_tpl->tpl_vars['zend_code_html']->value;?>
</textarea>
            </td>
        </tr>
    </table>

    <?php }?>
    <?php if (!empty($_smarty_tpl->tpl_vars['zend_code_buton']->value)){?>

    <table border="0" bgcolor="#CCCCCC" style="padding: 20px 50px;" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%" id="AutoNumber39">
        <tr>
            <td width="100%" height="30" valign="top"><b>
                    <font size="2" face="Tahoma" color="#800000"> SCI Buttons:</font></b></td>
        </tr>

        <tr>
            <td>
                <textarea readonly="readonly" rows="8" cols="80"><?php echo $_smarty_tpl->tpl_vars['zend_code_buton']->value;?>
</textarea>
            </td>
        </tr>
    </table>

    <?php }?>
    <?php if (!empty($_smarty_tpl->tpl_vars['zend_code_form']->value)){?>

    <table border="0" bgcolor="#CCCCCC" style="padding: 20px 50px;" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%" id="AutoNumber39">
        <tr>
            <td width="100%" height="30" valign="top"><b>
                    <font size="2" face="Tahoma" color="#800000"> SCI Form:</font></b></td>
        </tr>

        <tr>
            <td>
                <textarea readonly="readonly" rows="8" cols="80"><?php echo $_smarty_tpl->tpl_vars['zend_code_form']->value;?>
</textarea>
            </td>
        </tr>
    </table>
    
    <?php }?>
</div><?php }} ?>