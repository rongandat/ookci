<?php /* Smarty version Smarty-3.1.14, created on 2013-08-16 06:32:32
         compiled from "application\views\templates\sci\process.html" */ ?>
<?php /*%%SmartyHeaderCode:16512520c85aaca8cc7-08733533%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'a5600460fc3afea8d67f5e5634c4ddcd3416bf51' => 
    array (
      0 => 'application\\views\\templates\\sci\\process.html',
      1 => 1376625554,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '16512520c85aaca8cc7-08733533',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.14',
  'unifunc' => 'content_520c85aad8a1d8_81244575',
  'variables' => 
  array (
    'errors' => 0,
    'user_info' => 0,
    'sci_info' => 0,
    'foo' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_520c85aad8a1d8_81244575')) {function content_520c85aad8a1d8_81244575($_smarty_tpl) {?><?php if (!is_callable('smarty_modifier_base64_decode')) include 'F:\\ookcash\\system\\Smarty\\libs\\plugins\\modifier.base64_decode.php';
?><div class="simple-form">
    <?php if (empty($_smarty_tpl->tpl_vars['errors']->value)){?>
    <h1>Pay with a OOKCASH Account</h1>
    <p> OOKCASH is the secure payment processor for your merchant. </p>
    <div class="line"></div>
    <div class="clear"></div>
    <form action="<?php echo site_url('login');?>
" method="post">
        <table class="form">
            <tbody>
                <tr>
                    <td >
                        Pay to account
                    </td>
                    <td >
                        <?php echo $_smarty_tpl->tpl_vars['user_info']->value['account_number'];?>
(<strong><?php echo $_smarty_tpl->tpl_vars['user_info']->value['account_name'];?>
</strong>)
                    </td>
                </tr>
                <tr>
                    <td >
                        Amount
                    </td>
                    <td >
                        <?php echo $_smarty_tpl->tpl_vars['sci_info']->value['checkout_amount'];?>

                    </td>
                </tr>
                <tr>
                    <td >
                        Currency
                    </td>
                    <td >
                        <?php echo $_smarty_tpl->tpl_vars['sci_info']->value['checkout_currency'];?>

                    </td>
                </tr>
                <tr>
                    <td >
                        <div class="buttons">
                            <input class="button" type="submit" value="Login">
                            <?php if (!empty($_smarty_tpl->tpl_vars['sci_info']->value['cancel_url'])){?>
                            <input  type="button" name="buttonCancel" class="button"  value="Cancel" onclick="redirect('<?php echo smarty_modifier_base64_decode($_smarty_tpl->tpl_vars['sci_info']->value['cancel_url']);?>
');" />
                            <?php }?>
                        </div>
                    </td>
                    <td >
                    </td>
                </tr>
            </tbody>
        </table>
    </form>
    <?php }else{ ?>
    <h1>Errors</h1>
    <div class="line"></div>

    <div class="error">
        <ul>
            <?php  $_smarty_tpl->tpl_vars['foo'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['foo']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['errors']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['foo']->key => $_smarty_tpl->tpl_vars['foo']->value){
$_smarty_tpl->tpl_vars['foo']->_loop = true;
?>
            <li><?php echo $_smarty_tpl->tpl_vars['foo']->value;?>
</li>
            <?php } ?>
        </ul>
    </div>

    <?php }?>
</div>

<?php }} ?>