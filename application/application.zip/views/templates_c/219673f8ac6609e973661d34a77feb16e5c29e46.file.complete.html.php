<?php /* Smarty version Smarty-3.1.14, created on 2013-08-16 11:59:02
         compiled from "application\views\templates\sci\complete.html" */ ?>
<?php /*%%SmartyHeaderCode:27265520df58bb28a56-51282479%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '219673f8ac6609e973661d34a77feb16e5c29e46' => 
    array (
      0 => 'application\\views\\templates\\sci\\complete.html',
      1 => 1376646863,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '27265520df58bb28a56-51282479',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.14',
  'unifunc' => 'content_520df58bc5a1f5_09086788',
  'variables' => 
  array (
    'success' => 0,
    'url' => 0,
    'transaction_data' => 0,
    'user_session' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_520df58bc5a1f5_09086788')) {function content_520df58bc5a1f5_09086788($_smarty_tpl) {?><div class="simple-form">
    <h1>Transfer Successful </h1>

    <?php echo $_smarty_tpl->getSubTemplate ("common/validate_error.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

    <?php if (!empty($_smarty_tpl->tpl_vars['success']->value)){?>
    <p>Your transfer was successful!.</p>
    <?php if (!empty($_smarty_tpl->tpl_vars['url']->value)){?>
    <p>you will redirect within 10 seconds.</p>
    <?php }?>
    <?php if (!empty($_smarty_tpl->tpl_vars['transaction_data']->value)){?>
    <table class="form">
        <tbody><tr>
                <td class="form_label"><font size="2" face="Tahoma">Date:</font></td>
                <td class="form_field"><font size="2" face="Tahoma"><?php echo $_smarty_tpl->tpl_vars['transaction_data']->value['transaction_time'];?>
</font></td>
            </tr>	
            <tr>
                <td class="form_label"><font size="2" face="Tahoma">Batch Number#:</font></td>
                <td class="form_field"><font size="2" face="Tahoma"><?php echo $_smarty_tpl->tpl_vars['transaction_data']->value['batch_number'];?>
</font></td>
            </tr>	
            <tr>
                <td class="form_label"><font size="2" face="Tahoma">From:</font></td>
                <td class="form_field"><font size="2" face="Tahoma"><?php echo $_smarty_tpl->tpl_vars['transaction_data']->value['from_account'];?>
(<strong><?php echo $_smarty_tpl->tpl_vars['user_session']->value['account_name'];?>
</strong>)</font></td>
            </tr>	    
            <tr>
                <td class="form_label"><font size="2" face="Tahoma">To:</font></td>
                <td class="form_field"><font size="2" face="Tahoma"><?php echo $_smarty_tpl->tpl_vars['transaction_data']->value['to_account'];?>
</font></td>
            </tr>	 
            <tr>
                <td class="form_label"><font size="2" face="Tahoma">Amount:</font></td>
                <td class="form_field"><font size="2" face="Tahoma"><?php echo $_smarty_tpl->tpl_vars['transaction_data']->value['amount_text'];?>
</font></td>
            </tr>	 
            <tr>
                <td class="form_label"><font size="2" face="Tahoma">Transaction Memo:</font></td>
                <td class="form_field"><font size="2" face="Tahoma"><?php echo $_smarty_tpl->tpl_vars['transaction_data']->value['transaction_memo'];?>
</font></td>
            </tr>	       
            <?php if (!empty($_smarty_tpl->tpl_vars['url']->value)){?>
            <tr>
                <td class="">

                </td>
                <td class="">
                    <a href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
" class="button">Return</a>
                </td>
            </tr>
            <?php }?>
        </tbody>
    </table>  
    <?php }?>
    <?php }else{ ?>
    <p>Your transfer was error!</p>
    <table class="form">
        <tr>
            <td class="">

            </td>
            <td class="">
                <a href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
" class="button">Return</a>
            </td>
        </tr>
    </table>
    <?php }?>
</div>

<?php if (!empty($_smarty_tpl->tpl_vars['url']->value)){?>
<script>
    var interval = 1000;
    var i = 3;
    var url = '<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
'
    
    setInterval(function(){
        i--;
        if(i == 0){
            location= url;
        }
    }, interval);
    
</script>

<?php }?><?php }} ?>