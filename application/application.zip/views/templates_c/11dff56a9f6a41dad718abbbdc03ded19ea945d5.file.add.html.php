<?php /* Smarty version Smarty-3.1.14, created on 2013-08-17 04:59:18
         compiled from "application\views\templates\wallet\add.html" */ ?>
<?php /*%%SmartyHeaderCode:29684520ee7068a2986-57812902%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '11dff56a9f6a41dad718abbbdc03ded19ea945d5' => 
    array (
      0 => 'application\\views\\templates\\wallet\\add.html',
      1 => 1376708357,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '29684520ee7068a2986-57812902',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'success' => 0,
    'posts' => 0,
    'balance_currencies' => 0,
    'balance_currency' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.14',
  'unifunc' => 'content_520ee7069d43a5_62632471',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_520ee7069d43a5_62632471')) {function content_520ee7069d43a5_62632471($_smarty_tpl) {?><?php if (!is_callable('smarty_function_html_options')) include 'F:\\ookcash\\system\\Smarty\\libs\\plugins\\function.html_options.php';
?><form name="frmTransfer" method="post" action=""  >
    <div class="simple-form">
        <h1>Transfer To Wallet</h1>
        <p>Please use this form to transfer funds to wallet</p>
        <p>Fields marked with asterisk (<i>*</i>) are required.</p>
        <div class="line"></div>
        <?php echo $_smarty_tpl->getSubTemplate ("common/validate_error.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

        <?php if (!empty($_smarty_tpl->tpl_vars['success']->value)){?>
        <div class="success">Transfer success</div>
        <?php }?>
        <div class="st-form-line">
            <span class="st-labeltext"><i>*</i> Currency:</span>
            <?php if (!empty($_smarty_tpl->tpl_vars['posts']->value['balance_currency'])){?>
            <?php $_smarty_tpl->tpl_vars["balance_currency"] = new Smarty_variable($_smarty_tpl->tpl_vars['posts']->value['balance_currency'], true, 0);?>
            <?php }else{ ?>
            <?php $_smarty_tpl->tpl_vars["balance_currency"] = new Smarty_variable(0, true, 0);?>
            <?php }?>
            <select name="balance_currency" >
                <?php echo smarty_function_html_options(array('options'=>$_smarty_tpl->tpl_vars['balance_currencies']->value,'selected'=>$_smarty_tpl->tpl_vars['balance_currency']->value),$_smarty_tpl);?>

            </select>
            <div class="clear"></div>
        </div>
        <div class="st-form-line">
            <span class="st-labeltext"><i>*</i> Amount:</span>
            <input  name="amount" type="text" id="amount"  value="<?php if (!empty($_smarty_tpl->tpl_vars['posts']->value['amount'])){?><?php echo $_smarty_tpl->tpl_vars['posts']->value['amount'];?>
<?php }?>"  size="10" />
            <div class="clear"></div>
        </div>

        <div class="st-form-line">
            <span class="st-labeltext"><i>*</i> Master Key(3 digits)</span>
            <input  name="master_key" type="password" id="master_key"  value=""  size="4"  maxlength="3"/> 
            <div class="clear"></div>
        </div>
        <div class="st-form-line captcha">
            <span class="st-labeltext"></span>
            <input  type="submit" class="button"  value="Transfer" />
        </div>
    </div>
</form><?php }} ?>