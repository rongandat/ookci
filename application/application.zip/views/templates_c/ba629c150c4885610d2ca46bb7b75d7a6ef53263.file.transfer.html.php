<?php /* Smarty version Smarty-3.1.14, created on 2013-08-16 06:32:56
         compiled from "application\views\templates\sci\transfer.html" */ ?>
<?php /*%%SmartyHeaderCode:12350520c93c0db6386-12713632%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'ba629c150c4885610d2ca46bb7b75d7a6ef53263' => 
    array (
      0 => 'application\\views\\templates\\sci\\transfer.html',
      1 => 1376625554,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '12350520c93c0db6386-12713632',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.14',
  'unifunc' => 'content_520c93c0e8de91_25272262',
  'variables' => 
  array (
    'sci_info' => 0,
    'sci_user' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_520c93c0e8de91_25272262')) {function content_520c93c0e8de91_25272262($_smarty_tpl) {?><div class="simple-form">
    <form name="frmTransfer" method="post" action=""  >
        <h1>Transfer</h1>

        <p>Please use this form to transfer funds from your Gwebcash to another member.</p>
        <p>Fields marked with asterisk (<i>*</i>) are required.</p>
        <div class="line"></div>
        <?php echo $_smarty_tpl->getSubTemplate ("common/validate_error.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

        <?php if (!empty($_smarty_tpl->tpl_vars['sci_info']->value)){?>
        <table class="form">

            <tr>
                <td class="form_label"><i>*</i> To Account:</td>
                <td class="form_field">
                    <?php echo $_smarty_tpl->tpl_vars['sci_info']->value['payee_account'];?>
 (<?php echo $_smarty_tpl->tpl_vars['sci_user']->value['account_name'];?>
)
            </tr>		  
            <tr>
                <td class="form_label"><i>*</i> Amount (<?php echo $_smarty_tpl->tpl_vars['sci_info']->value['checkout_currency'];?>
)</td>
                <?php if (empty($_smarty_tpl->tpl_vars['sci_info']->value['checkout_amount'])){?>
                <td class="form_field"><input type="text" name="checkout_amount" class="inputtext"/></td>
                <?php }else{ ?>
                <td class="form_field"><?php echo $_smarty_tpl->tpl_vars['sci_info']->value['checkout_amount'];?>
</td>
                <?php }?>
            </tr>	  
            <tr>
                <td class="form_label">Transaction Memo:</td>
                <td  class="form_field"><textarea name="transaction_memo"  cols="50" rows="3"></textarea> </td>
            </tr>
            <tr>
                <td class="form_label"><i>*</i> Master Key:</td>
                <td  class="form_field"><input  name="master_key" type="password" id="master_key"  value=""  size="4"  maxlength="3"/> (3 digits)</td>
            </tr>		  	  	  
            <tr>
                <td class="form_label"></td>
                <td  class="form_field"><input  type="submit" name="buttonPreview" class="button"  value="Preview" /></td>
            </tr>		  	  	  
        </table>

    </form>

    <?php }?>
</div><?php }} ?>